/* program that prints out the sum of all arguments on the 
    command line, now assuming that they are doubles. */


#include <stdio.h>

main(int argc, char **argv)
{
  int i;
  double sum, d;

  sum = 0;

  for (i = 1; i < argc; i++) {
    sscanf(argv[i], "%lf", &d);
    sum += d;
  }
  printf("%lf\n", sum);
}
