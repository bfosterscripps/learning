#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "fields.h"
#include "flcommon4.h"


typedef struct {
  double nsongs, ttime;
  double ncsongs, tctime;
  double nrsongs, trtime;
  double nosongs, totime;
} Music_Info;

void *read_music_file(char *filename)
{
  IS is;
  int time;
  char *x;
  Music_Info *mi;

  mi = (Music_Info *) malloc(sizeof(Music_Info));
  if (mi == NULL) { perror("malloc music_info"); exit(1); }

  mi->ttime = 0;
  mi->tctime = 0;
  mi->trtime = 0;
  mi->totime = 0;
  mi->nsongs = 0;
  mi->ncsongs = 0;
  mi->nrsongs = 0;
  mi->nosongs = 0;

  is = new_inputstruct(filename);
  if (is == NULL) { perror(filename); exit(1); }

  while (get_line(is) >= 0) {
    mi->nsongs++;
    time = atoi(is->fields[1])*60;
    x = strchr(is->fields[1], ':') + 1;
    time += atoi(x);
    mi->ttime += time;
    if (strcmp(is->fields[4], "Rock") == 0) {
      mi->nrsongs++;
      mi->trtime += time;
    } else if (strcmp(is->fields[4], "Classical") == 0) {
      mi->ncsongs++;
      mi->tctime += time;
    } else {
      mi->nosongs++;
      mi->totime += time;
    }
  }
  jettison_inputstruct(is);
  return (void *) mi;
}

double  get_nsongs(void *mi) { 
  Music_Info *m;
  
  m = (Music_Info *) mi;
  return m->nsongs;
}

double get_ttime(void *mi) { return ((Music_Info *) mi)->ttime; }
double get_ncsongs(void *mi) { return ((Music_Info *) mi)->ncsongs; }
double get_tctime(void *mi) { return ((Music_Info *) mi)->tctime; }
double get_nrsongs(void *mi) { return ((Music_Info *) mi)->nrsongs; }
double get_trtime(void *mi) { return ((Music_Info *) mi)->trtime; }
double get_nosongs(void *mi) { return ((Music_Info *) mi)->nosongs; }
double get_totime(void *mi) { return ((Music_Info *) mi)->totime; }
