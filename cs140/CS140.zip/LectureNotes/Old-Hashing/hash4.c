#include <stdlib.h>
#include <string.h>
#include "fields.h"

int hash(char *s)
{
  int total;
  int i;
  int c1, c2, c3;
  
  total = 0;
  for (i = 0; s[i] != '\0'; i++) {
    total = total * 27 + s[i];
  }
  if (total < 0) total = -total;
  return total;
}

main(int argc, char **argv)
{
  IS is;
  int table_size;
  int *hashes;
  int h;
  double ncollisions;
  double nl;

  ncollisions = 0;
  nl = 0;

  if (argc != 2) {
    fprintf(stderr, "usage: hash2 table_size\n");
    exit(1);
  }
  table_size = atoi(argv[1]);
  if (table_size <= 0) {
    fprintf(stderr, "usage: hash2 table_size (> 0)\n");
    exit(1);
  }

  hashes = (int *) malloc(sizeof(int) * table_size);
  if (hashes == NULL) { perror("malloc"); }
  for (h = 0; h < table_size; h++) hashes[h] = 0;

  is = new_inputstruct(NULL);

  while(get_line(is) >= 0) {
    nl++;
    is->text1[strlen(is->text1)-1] = '\0';
    h = hash(is->text1);
    h = h % table_size;
    if (hashes[h] != 0) ncollisions++;
    hashes[h]++;
  }
  printf("%.0lf lines, %.0lf collisions: %.2lf\n", nl, 
         ncollisions, ncollisions * 100.0 / nl);
}
