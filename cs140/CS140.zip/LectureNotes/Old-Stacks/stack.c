#include <stdio.h>
#include <string.h>
#include "jval.h"
#include "dllist.h"
#include "stack.h"
#include "stack.h"

typedef struct stacknode {
  struct stacknode *next;
  Jval val;
} Stack_Node;

typedef struct {
  int size;
  Stack_Node *top;
} True_Stack;

Stack new_stack()    /* Create an empty stack */
{
  True_Stack *ts;

  ts = (True_Stack *) malloc(sizeof(True_Stack));
  if (ts == NULL) { perror("malloc in new_stack()"); exit(1); }
  ts->top = NULL;
  ts->size = 0;
  return (Stack) ts;
}

void stack_push(Stack s, Jval jv)  /* Push an element onto the stack */
{
  True_Stack *ts;
  Stack_Node *n;

  ts = (True_Stack *) s;
  n = (Stack_Node *) malloc(sizeof(Stack_Node));
  if (n == NULL) { perror("stack_push"); exit(1); }
  n->next = ts->top;
  n->val = jv;
  ts->top = n;
  ts->size++;
}

Jval stack_pop(Stack s)  /* Pop an element off the stack.  Will exit with an error
                             if the stack is empty */
{
  True_Stack *ts;
  Jval jv;
  Stack_Node *n;

  ts = (True_Stack *) s;
  if (ts->size == 0) {
    fprintf(stderr, "stack_pop -- popping empty stack\n"); 
    exit(1);
  }
  n = (ts->top);
  ts->top = n->next;
  jv = n->val;
  free(n);
  ts->size--;
  return jv;
}

void free_stack(Stack s) /* This destroys the stack and      
                             frees any memory made by malloc() calls from 
                             within the stack routines.  */
{
  True_Stack *ts;

  while (!stack_empty(s)) (void) stack_pop(s);
  ts = (True_Stack *) s;
  free(ts);
}

Jval stack_top(Stack s) /* This returns the same value as stack_pop(), 
                            only the value is not removed from the stack.  */
{
  True_Stack *ts;

  ts = (True_Stack *) s;
  if (ts->size == 0) {
    fprintf(stderr, "stack_top -- empty stack\n"); 
    exit(1);
  }
  return ts->top->val;
}


int stack_empty(Stack s) /* This is a boolean function that returns 1 
                            if there are no elements on the stack, 
                            and 0 if there are elements on the stack.  */
{
  True_Stack *ts;

  ts = (True_Stack *) s;
  return (ts->size == 0);
}

int stack_size(Stack s)  /* This returns the number of elements in s. */
{
  True_Stack *ts;

  ts = (True_Stack *) s;
  return ts->size;
}

