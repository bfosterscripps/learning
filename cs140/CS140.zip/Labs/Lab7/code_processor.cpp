/**
 * Lab7 - code_processor.cp
 *
 * descr
 * 
 * Author: William McKeehan
 * Date: 03-14-2012
 */
#include "code_processor.h"
#include <sstream>

using namespace std;

unsigned int djb_hash(string &s); //Implement the djb_hash - taken from lecture notes

/**
 * This creates a new prize and puts it into Prizes.
 * It will return zero if all is ok.
 * It will return -1 from the following errors without creating anything new:
 * - 	There is already a prize with the given id in prizes.
 * - 	Points is less than or equal to zero.
 * - 	Quantity is less than or equal to zero. 
 */
int Code_Processor::New_Prize(string id, string description, int points, int quantity)
{
	Prize *newPrize;

	if ( points <= 0 ) return -1;
	if ( quantity <= 0 ) return -1;
	if ( Prizes.find(id) != Prizes.end() ) return -1;

	newPrize = new Prize();
	newPrize->id = id;
	newPrize->description = description;
	newPrize->points = points;
	newPrize->quantity = quantity;

	Prizes.insert(make_pair(id, newPrize));

	return 0;
}

/**
 * This creates a new user with the given information, and puts it into Names.
 * It will return zero if all is ok.
 * It will return -1 from the following errors without creating anything new:
 * - There is already a user with that username.
 * - Starting_points is less than zero. 
 */
int Code_Processor::New_User(string username, string realname, int starting_points)
{
	User *newUser;

	if( starting_points < 0 ) return -1;
	if( Names.find(username) != Names.end() ) return -1;

	newUser = new User();
	newUser->username = username;
	newUser->realname = realname;
	newUser->points = starting_points;

	Names.insert(make_pair(username, newUser));

	return 0;
}

/**
 * This will erase the user from Names, and it will erase all of the user's
 * phone numbers from Phones.
 * It will return zero if all is ok.
 * It will return -1 if the username is not in Names. 
 */
int Code_Processor::Delete_User(string username)
{
	map <string, User *>::iterator namesIt;
	map <string, User *>::iterator phonesIt;
	set <string>::iterator userPhonesIt;

	namesIt = Names.find(username);
	if( namesIt == Names.end() ) return -1;

	//delete users phone numbers first
	for( userPhonesIt = namesIt->second->phone_numbers.begin(); userPhonesIt != namesIt->second->phone_numbers.end() ; userPhonesIt++ ) {
		phonesIt = Phones.find(*userPhonesIt);
		if( phonesIt != Phones.end() ) Phones.erase(phonesIt);
	}
	delete namesIt->second; //delete the User memory space
	Names.erase(namesIt);

	return 0;
}

/**
 * This will register the given phone string with the user.
 * It will return zero if all is ok.
 * It will return -1 from the following errors without creating anything new: 
 * - There is no user with that username.
 * - The phone number is already registered, either with that user or with another. 
 */
int Code_Processor::Add_Phone(string username, string phone)
{
	map <string, User *>::iterator namesIt;
	map <string, User *>::iterator phonesIt;

	namesIt = Names.find(username);
	if( namesIt == Names.end() ) return -1;

	phonesIt = Phones.find(phone);
	if( phonesIt != Phones.end() ) return -1;

	Phones.insert(make_pair(phone, namesIt->second));
	namesIt->second->phone_numbers.insert(phone);

	return 0;
}

/**
 * This will remove the phone from the system.
 * It will return zero if all is ok.
 * It will return -1 from the following errors without performing any system modifications:
 * - There is no user with that username.
 * - There is no phone string with that phone.
 * - The phone number is registered to a different user. 
 */
int Code_Processor::Remove_Phone(string username, string phone)
{
	map <string, User *>::iterator namesIt;
	map <string, User *>::iterator phonesIt;
	set <string>::iterator userPhonesIt;

	phonesIt = Phones.find(phone);
	if( phonesIt == Phones.end() ) return -1;
	if( phonesIt->second->username != username ) return -1;

	namesIt = Names.find(username);
	if( namesIt == Names.end() ) return -1;

	userPhonesIt = namesIt->second->phone_numbers.find(phone);
	if( userPhonesIt == namesIt->second->phone_numbers.end() ) return -1;

	namesIt->second->phone_numbers.erase(*userPhonesIt);
	Phones.erase(phonesIt);

	return 0;
}

/**
 * This will return a string containing all of a user's phone numbers,
 * in lexicographic order, each separated by a newline.
 * It will return "BAD USER" if the user doesn't exist.
 * It will return an empty string if the user has no phones. 
 */
string Code_Processor::Show_Phones(string username)
{
	ostringstream os;
	map <string, User *>::iterator mit;
	set <string, User *>::iterator pit;

	mit = Names.find(username);
	if( mit == Names.end() ) return "BAD USER";

	os.clear();
	os.str("");
	for( pit = mit->second->phone_numbers.begin() ; pit != mit->second->phone_numbers.end() ; pit++ ) {
		os << *pit << endl;
	}
	return os.str();
}

/**
 * This is called when a user enters a code.
 * It will return -1 from the following errors without performing any system modifications:
 * - If the code has been used before. 
 * - If the user doesn't exist.
 * It will return 0 if the code is not valid. 
 * If the code is valid (a valid code's djbhash() must either be divisible by 17 or 13.)
 *   - then add it to the used codes list,
 *   - increment the user's account by
 *     - 10 if divisible by 17 or
 *     - 3  if divisible by 13
 *   - return the number of points added.
 */
int Code_Processor::Enter_Code(string username, string code)
{
	unsigned int djb;
	int worth;
	map <string, User *>::iterator mit;

	mit = Names.find(username);
	if( mit == Names.end() ) return -1;
	if( Codes.find(code) != Codes.end() ) return -1;

	djb = djb_hash(code);
	if ( ( djb % 17 ) == 0 ) {
		worth = 10;
	} else if ( ( djb % 13 ) == 0 ) {
		worth = 3;
	} else {
		worth = 0;
	}

	if( worth > 0 ) {
		Codes.insert(code);
		mit->second->points += worth;
	}

	return worth;
}

/**
 * This works just like Enter_Code(), except the user's account is identified by the phone number.
 * It will return -1 if the phone number doesn't exist.
 * Otherwise, this should work just like Enter_Code(). 
 */
int Code_Processor::Text_Code(string phone, string code)
{
	map <string, User *>::iterator phonesIt;

	phonesIt = Phones.find(phone);
	if( phonesIt == Phones.end() ) return -1;

	return Enter_Code(phonesIt->second->username, code);
}

/**
 * This is called to mark a code as used, even though no user is entering it.
 * This is used to help rebuild the server from a saved state.
 * It returns -1 if the code is not valid or it is already in Codes.
 * Otherwise, add it to Codes and return 0.
 */
int Code_Processor::Mark_Code_Used(string code)
{
	unsigned int djb;

	if( Codes.find(code) != Codes.end() ) return -1;

	djb = djb_hash(code);
	if( ( ( djb % 17 ) == 0 ) || ( ( djb % 13 ) == 0 )) {
		Codes.insert(code);
		return 0;
	}
	return -1;
}

/**
 * This should return the user's points. If the user doesn't exist, return -1.
 */
int Code_Processor::Balance(string username)
{
	map <string, User *>::iterator namesIt;

	namesIt = Names.find(username);
	if( namesIt == Names.end() ) return -1;

	return namesIt->second->points;
}

/**
 * This is called when a user wants to redeem a prize.
 * It will return -1 from the following errors without performing any system modifications:
 * - if the user or prize don't exist.
 * - if the user doesn't have enough points.
 * 
 * Decrement the points from the user's account, and decrement the prize's quantity by one.
 * If the prize's quantity is zero, remove the prize from the system.
 */
int Code_Processor::Redeem_Prize(string username, string prize)
{
	map<string, User *>::iterator namesIt;
	map<string, Prize *>::iterator prizeIt;

	namesIt = Names.find(username);
	if( namesIt == Names.end() ) return -1;

	prizeIt = Prizes.find(prize);
	if( prizeIt == Prizes.end() ) return -1;

	if( prizeIt->second->points > namesIt->second->points ) return -1;

	//decrement the points from the users account
	namesIt->second->points -= prizeIt->second->points;

	//decrement the prize's quantity
	if ( prizeIt->second->quantity == 1 ) {
		//remove the prize from the sytem if none left
		delete prizeIt->second;
		Prizes.erase(prizeIt);
	}	else{
		prizeIt->second->quantity -= 1;
	}

	return 0;
}

/**
 * Destructor to delete all users and prizes
 */
Code_Processor::~Code_Processor()
{
	map <string, User *>::iterator namesIt;
	map <string, Prize *>::iterator prizesIt;

	for( namesIt = Names.begin() ; namesIt != Names.end() ; namesIt++ ) delete namesIt->second;
	for( prizesIt = Prizes.begin() ; prizesIt != Prizes.end() ; prizesIt++ ) delete prizesIt->second;

}

/**
 * save the Code_Processor's state to the given file and return 0.
 * It will return -1 if it can't open/create the file.
 *
 * The output of Write() is a file that cp_tester can use as input to recreate the state of the Code_Processor.
 * It consist of ADD_USER, PRIZE, ADD_PHONE and MARK_USED lines.
 */
int Code_Processor::Write(const char *file)
{
	ofstream of;
	map<string, User *>::iterator uit;
	map<string, Prize *>::iterator pit;
	set<string>::iterator cit;

	of.open(file);
	if( of.fail() ) return -1;

	for( pit = Prizes.begin() ; pit != Prizes.end() ; pit++ ) {
		of << "PRIZE " << pit->first << " " << pit->second->points << " " << pit->second->quantity << " " << pit->second->description << endl;
	}
	for( uit = Names.begin() ; uit != Names.end() ; uit++ ) {
		of << "ADD_USER " << uit->first << " " << uit->second->points << " " << uit->second->realname << endl;
	}
	for( uit = Phones.begin() ; uit != Phones.end() ; uit++ ) {
		of << "ADD_PHONE " << uit->second->username << " " << uit->first << endl;
	}
	for( cit = Codes.begin() ; cit != Codes.end() ; cit++ ) {
		of << "MARK_USED " << *cit << endl;
	}


	of.close();

	return 0;
}

/**
 * Implement the djb_hash - taken from lecture notes
 */
unsigned int djb_hash(string &s)
{
	int i;
	unsigned int h;

	h = 5381;

	for (i = 0; i < s.size(); i++) {
		h = (h << 5) + h + s[i];
	}
	return h;
}
