#include <iostream>     //for console input/output
#include <string>       //for c++ style strings
#include <vector>       //for c++ style strings
#include <map>

using namespace std;

typedef vector<string> Grid;
typedef vector<int> Cord;

class ShapeShifter {
	public:
		ShapeShifter(Grid g);
		void AddShape(Grid shape);
		void PrintSolution();
		void PrintGrid();

	protected:
		Grid grid;						//the grid to solve
		vector<Grid> shapes;	//a collection of shapes
		map<int, Cord> soln;	//map of the solution (shape, coordinates)
		void Apply(Grid shape, int row, int column);
		bool find_solution(int index);
};
