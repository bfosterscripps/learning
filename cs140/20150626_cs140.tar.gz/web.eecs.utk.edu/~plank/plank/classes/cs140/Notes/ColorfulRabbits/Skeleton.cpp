#include <string>
#include <vector>
#include <list>
#include <algorithm>
#include <map>
#include <set>
#include <iostream>
#include <cstdio>
#include <cstdlib>
using namespace std;

class ColorfulRabbits {
  public:
    int getMinimum(vector <int> replies);
};

int ColorfulRabbits::getMinimum(vector <int> replies)
{
  return 0;
}
