/**
 * Lab4 - hash140.cpp
 *
 * This defines a HashTable class.
 * It will be used to store keys and values; both are strings.
 * The keys are strings of hexadecimal digits.
 * They may be of arbitrary size. The values are strings.
 * 
 * Author: William McKeehan
 * Date: 02-15-2012
 */
#include "hash140.h"
#include <cstdio>
#include <sstream>
#include <cstdlib>      //for exit

int XOR(string &key);		//the XOR hash function
int Last7(string &key);	//the Last7 hash function
int findIndex(int find, string &key, vector<string> &keys, int Fxn, int Coll, int &tmp ); //find an index

/**
 * constructor
 * We will support two hash functions, "Last7" and "XOR".
 * The hash table will use open addressing with one of two collision resolution
 * strategies: "Linear" for linear probing and "Double" for double hashing.
 */
HashTable::HashTable(int table_size, string function, string collision)
{
	//initalize and size the vectors to hold the data
	keys.resize(table_size,"");
	vals.resize(table_size,"");

	//determine which hash function will be the primary
	if( function == "Last7" ) {
		Fxn = 1; //Last7
	} else {
		Fxn = 0; //XOR
	}

	//determine which colliion resolution method wil be used
	if( collision == "Linear" ) {
		Coll = 1; //Linear
	} else {
		Coll = 0; //Double Hash
	}

	//initialize the other variables
	nkeys = 0;
	tmp = 0;
} //end HashTable::HashTable

/**
 * Add a given key/val pair to the hash table
 */
void HashTable::Add_Hash(string &key, string &val)
{
	int index;

	if( nkeys >= keys.size() ) {
		cerr << "Hash Table Full\n";
		exit(1);
		return;
	}

	index = findIndex(0, key, keys, Fxn, Coll, tmp );
	if( index != -1 ) {
		nkeys++;
		keys[index] = key;
		vals[index] = val;
	} else {
		cerr << "Couldn't put " << key << " into the table\n";
		exit(1);
	}
} //end HashTable::Add_Hash

/**
 * looks for the given key in the hash table and returns its associated value,
 * or the empty string if the key is not in the hash table
 */
string HashTable::Find(string &key)
{
	int index;

	index = findIndex(1, key, keys, Fxn, Coll, tmp);

	if( index != -1 ) {
		return vals[index];
	} else {
		return "";
	}
} //end HashTable::Find

/**
 * should print all non-empty slots in the hash table, one per line.
 * The index should be printed first, right justified and padded to five characters.
 * Then the key and the value, each separated by a space.
 */
void HashTable::Print()
{
	int i;

	for( i = 0 ; i < keys.size() ; i++ ) {
		if( keys[i] != "" ) printf("%5d %s %s\n", i, keys[i].c_str(), vals[i].c_str());
	}
} //end HashTable::Print

/**
 * traverses the hash table, and for every key, calculates how many probes it takes to find the key.
 */
int HashTable::Total_Probes()
{
	int i;
	int totalProbes;

	totalProbes = 0;

	for( i = 0 ; i < keys.size() ; i++ ) {
		if( keys[i] != "" ) {
			Find(keys[i]);
			totalProbes += tmp;
		}
	}

	return totalProbes;
} //end HashTable::Total_Probes

/**
 * The first is called Last7.
 * It treats the last seven digits of the hash string as a number in hexadecimal.
 * Thus, the hash of "b9937df3fefbe66d8fcdda363730bf14" will be 120635156, which
 * is equal to 0x730bf14. If the string has fewer than 7 characters, then simply
 * treat the whole string as a hexadecimal number. Thus, the hash of "11" will be
 * 17, which is equal to 0x11.
 */
int Last7(string &key) 
{
	int hash;
	int start;
	istringstream ss;

	start = (key.size() - 7) ;
	start = ( (0 > start) ? 0 : start );
	ss.clear();
	ss.str( key.substr(start) );
	ss >> hex >> hash;

	return hash;
} //end Last7

/**
 * The second hash function is called XOR.
 * With this hash function, you break up* the string into seven-character words,
 * and then treat each word as a number in hexadecimal.
 * You then calculate the bitwise exclusive-or of each of these numbers. That is your hash function.
 * So, let's take an easy example: "a000000a0000101". First, we break this up into
 * seven-digit words (except for the last one): "a000000", "a000010" and "1".
 * Their bitwise exclusive-or is equal to 0x11, so the XOR hash of "a000000a0000101" is equal to 17.
 */
int XOR(string &key)
{
	int hash = 0;
	int tmp;
	int i;
	istringstream ss;

	for ( i = 0 ; i < key.size() ; i += 7 ) {
		ss.clear();
		ss.str( key.substr(i,7) );
		ss >> hex >> tmp;
		hash = hash ^ tmp;
	}

	return hash;
} //end XOR

/**
 * This function does all of the heavy lifting of finding an empty slot (find = 0)
 * or the index which matches the key.
 */
int findIndex(int find, string &key, vector<string> &keys, int Fxn, int Coll, int &tmp )
{
	int i;
	int hash1;
	int hash2;
	int table_index;
	int hash2_index;
	int table_size;
	string target_value = "";

	tmp = 0;

	if( find ) 
		target_value = key;

	table_size = keys.size();

	if( Fxn ) {
		hash1 = Last7(key);
	} else {
		hash1 = XOR(key);
	}

	table_index = hash1 % table_size;
	if( keys[table_index] == target_value ) {
		return table_index;
	} else {
		//Collision - decide which method to use to resolve
		if( Coll ) {
			//Linear
			for ( i = 1 ; i < table_size; i++ ) {
				tmp++;
				table_index = ( hash1 + i ) % table_size;
				if( keys[table_index] == target_value ) {
					return table_index;
				}
			}
		} else {
			//Double Hash
			if( !Fxn ) {
				hash2 = Last7(key);
			} else {
				hash2 = XOR(key);
			}
			hash2_index = hash2 % table_size;
			if( hash2_index == 0 ) hash2_index = 1;
			for( i = 1 ; i < table_size; i++ ) {
				tmp++;
				table_index = ( hash1 + ( i * hash2_index ) ) % table_size;
				if( keys[table_index] == target_value ) {
					return table_index;
				}
			}
		}
	}

	return -1;
} //end findIndex
