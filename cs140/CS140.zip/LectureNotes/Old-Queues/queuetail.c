#include <stdio.h>
#include <string.h>
#include "queue.h"
#include "fields.h"
 
main(int argc, char **argv)
{
  Queue q;
  int n, i;
  IS is;
  Jval v;

  if (argc != 2) {
    fprintf(stderr, "usage: queuetail n\n");
    exit(1);
  }

  n = atoi(argv[1]);
  if (n < 0) exit(1); 

  q = new_queue();
  is = new_inputstruct(NULL);

  while (get_line(is) >= 0) {
    queue_enqueue(q, new_jval_s(strdup(is->text1)));
    if (queue_size(q) > n) {
      v = queue_dequeue(q);
      free(v.s);
    }
  }

  while (!queue_empty(q)) {
    printf("%s", jval_s(queue_dequeue(q)));
  }
} 
