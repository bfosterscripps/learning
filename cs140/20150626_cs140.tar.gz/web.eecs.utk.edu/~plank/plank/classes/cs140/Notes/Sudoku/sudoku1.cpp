#include "sudoku.h"

Sudoku::Sudoku()
{
}

void Sudoku::Print_Screen()
{
}

void Sudoku::Print_Convert()
{
}

int Sudoku::Solve()
{
  return 0;
}

int Sudoku::Is_Row_Valid(int r)
{
  return 0;
}

int Sudoku::Is_Col_Valid(int c)
{
  return 0;
}

int Sudoku::Is_Panel_Valid(int sr, int sc)
{
  return 0;
}

int Sudoku::Recursive_Solve(int r, int c)
{
  return 0;
}

