#include <stdio.h>
#include <stdlib.h>

int main()
{
  char s[16];
  int i;

  i = 261303714;

  while (1) {
    if (scanf("%s", s) != 1) return 0;
    printf("s = %s.  i = %d\n", s, i);
  }
}
