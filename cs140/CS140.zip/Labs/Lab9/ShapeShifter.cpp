/**
 * Lab9 - ShapeShifter.cpp
 *
 * Implementation of the ShapeShifter Class
 *
 * Author: William McKeehan
 * Date: 04-07-2012
 */

#include "ShapeShifter.h"

/**
 * The constructor - you have to supply a grid to be solved.
 */
ShapeShifter::ShapeShifter(Grid g)
{
	grid = g;
}

/**
 * Add a given shape to the collection of shapes given to solve this grid
 */
void ShapeShifter::AddShape(Grid shape)
{
	shapes.push_back(shape);
}

/**
 * Find and print a solution to the grid
 */
void ShapeShifter::PrintSolution()
{
	int j;
	map<int, Cord>::iterator mit;

	if( find_solution(0) ) {
		for( mit = soln.begin() ; mit != soln.end() ; mit++ ) {
			for( j = 0 ; j < shapes[mit->first].size() ; j++ ) {
				cout << shapes[mit->first][j] << " ";
			}
			for( j = 0 ; j < mit->second.size() ; j++ )
				cout << mit->second.at(j) << " ";
			cout << endl;
		}
	}
}

/**
 * Print the grid -used for debugging
 */
void ShapeShifter::PrintGrid()
{
	int r, c;

	for( r = 0 ; r < grid.size() ; r++ ) {
		for( c = 0 ; c < grid[0].size(); c++ )
			cout << grid[r][c];
		cout << endl;
	}
}

/**
 * applies a shape to the grid at a given row and column
 */
void ShapeShifter::Apply(Grid shape, int row, int column)
{
	int r, c;

	for( r = 0 ; r < shape.size() ; r++ )
		for( c = 0 ; c < shape[r].size() ; c++ )
			if ( shape[r][c] == '1' ) //if the shape has a 1, then flip the corresponding cell in the grid
				grid[row+r][column+c] = ( grid[row+r][column+c] == '0' ) ? '1' : '0' ;
}

/**
 * Try possible solutions one at a time until
 * a soltion is found; store the results in soln
 */
bool ShapeShifter::find_solution(int index)
{
	int r, c;
	vector<int> v;

	//we are out of shapes, do we have a solution?
	if( index == shapes.size() ) {
		for( r = 0 ; r < grid.size() ; r++ )	//not a solution if any row has a zero in it
			if( grid[r].find('0') != string::npos ) return false;

		return true; //no zeros found, so yes, it is solved!
	}

	//try each potential position until we find a solution
	for( r = 0 ; r < grid.size() ; r++ ) {
		if( r + shapes[index].size() <= grid.size() ) {
			for( c = 0 ; c < grid[r].size() ; c++ ) {
				if( c + shapes[index][0].size() <= grid[r].size() ) {
					Apply(shapes[index], r, c);
					if( find_solution(index + 1) ) {
						//solution found, add the solution for this shape to the soln map
						v.clear();
						v.push_back(r);
						v.push_back(c);
						soln.insert( make_pair(index, v) );
						return true;
					}
					Apply(shapes[index], r, c); //revert the grid to its original state
				}
			}
		}
	}
	//out of things to try...
	return false;
}
