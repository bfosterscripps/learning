hash4    1487 < input1.txt
hash4    4122 < input2.txt
hash4    2311 < input3.txt
hash4    8000 < input4.txt
echo ""
hash4    100000 < input1.txt
hash4    100000 < input2.txt
hash4    100000 < input3.txt
hash4    100000 < input4.txt

