#include <stdio.h>
#include "towers.h"
#include "fields.h"


/* ---------------------------------------------------------------------- */
/* Main -- allocate, then let the user manipulate */

main(int argc, char **argv)
{
  Dllist *towers;
  int npieces;
  IS is;
  int from, to;

  if (argc != 2) {
    fprintf(stderr, "usage: tower_play size\n");
    exit(1);
  }

  npieces = atoi(argv[1]);
  if (npieces <= 0) exit(1);

  towers = new_towers(npieces);
  print_towers(towers);

  is = new_inputstruct(NULL);

  while (1) {
    printf("TOWERS> ");
    fflush(stdout);
    if (get_line(is) < 0) exit(0);
    if (is->NF == 1 && strcmp(is->fields[0], "PRINT") == 0) {
      print_towers(towers);
    } else if (is->NF == 3 && strcmp(is->fields[0], "MOVE") == 0) {
      if (sscanf(is->fields[1], "%d", &from) != 1) {
        printf("MOVE from to: from must be a number\n");
      } else if (from < 0 || from > 2) {
        printf("MOVE from to: from must be a number between 0 and 2\n");
      } else {
        if (sscanf(is->fields[2], "%d", &to) != 1) {
          printf("MOVE from to: to must be a number\n");
        } else if (to < 0 || to > 2) {
          printf("MOVE from to: to must be a number between 0 and 2\n");
        } else {
          make_move(towers, from, to);
        }
      }
    } else if (is->NF == 1 && strcmp(is->fields[0], "QUIT") == 0) {
      exit(0);
    } else if (is->NF > 0) {
      printf("Valid entries are 'PRINT', 'MOVE from to' and 'QUIT'\n");
    }
  }
}
