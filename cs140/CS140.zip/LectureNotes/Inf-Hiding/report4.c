#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "fields.h"
#include "flcommon4.h"


main()
{
  void *mi;

  mi = read_music_file("Music.txt");

  print_report(mi);

  printf("\n");
  printf("Total number of songs (classical and non-classical): %.0lf\n", get_nsongs(mi));
}
