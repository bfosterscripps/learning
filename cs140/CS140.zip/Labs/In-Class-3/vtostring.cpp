#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include <iostream>
#include <sstream>
using namespace std;

// Write your code here:
/**
 * Lab3-InClass - vtostring.cpp
 *
 * Join a vector of strings into a single string
 * 
 * Author: William McKeehan
 * Date: 02-01-2012
 */

//takes a vector of strings and converts it to a single string
string words_to_string(vector<string> inStrings) {
	istringstream ss;
	string s, ret = "";
	int i;

	//loop through all of the input strings
	for( i = 0 ; i < inStrings.size() ; i++ ) {
		ss.clear();
		ss.str(inStrings.at(i));
		//then add each word to the return string
		while( ss >> s ) {
			if ( ret.size() ) ret += " "; //add a space if this is not the first
			ret += s;
		}
	}

	return ret;
} //end words_to_string

// DO NOT CHANGE ANYTHING BELOW THIS LINE

main()
{
  int i;
  string s;
  vector <string> words;
  
  i = 0;
  while (cin >> s) {
    i++;
    words.push_back(s);
    if (i % 10 == 0) {
      s = words_to_string(words);
      printf("Words %3d to %3d: %s\n", i-9, i, s.c_str());
      words.clear();
    }
  }
  if (i % 10 != 0) {
    s = words_to_string(words);
    if (i % 10 == 1) {
      printf("Word  %3d:        %s\n", i, s.c_str());
    } else {
      printf("Words %3d to %3d: %s\n", i-(i%10)+1, i, s.c_str());
    }
  }
}
