#include <stdio.h>
#include <stdlib.h>

int main()
{
  int i;
  double d;

  /* Forgetting a parameter */

  printf("1. %d\n");

  /* Trying to print an integer as a double without casting it */

  i = 5;
  printf("2. %lf\n", i);

  /* Trying to print a double as integer without casting it */

  d = 5;
  printf("3. %d\n", d);

  /* Trying to print a string as an integer, even though it's a string of an integer */

  printf("4. %d\n", "5");

  /* Trying to print an integer as a string */

  printf("5. %s\n", i);

  return 0;
}
