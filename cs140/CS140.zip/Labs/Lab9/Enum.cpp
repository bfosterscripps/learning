/**
 * Lab9 - enum.cp
 *
 * descr
 * 
 * Author: William McKeehan
 * Date: 04-07-2012
 */
#include <cmath>        //for sqrt
#include <cstdlib>      //for exit
#include <cstdio>				//for printf
#include <fstream>      //for file input/output
#include <iomanip>      //for formatting output with setw and setprecision
#include <iostream>     //for console input/output
#include <sstream>      //for converting an int to a string
#include <stdio.h>			//required for getline
#include <string>       //for c++ style strings
#include <vector>       //for vectors
#include "Enum.h"

using namespace std;

void usage()
{
	cerr << "usage: enum length nones" << endl;
	exit(1);
}

int main(int argc, char **argv)
{
	/**
	 * My main() processes the command line arguments,
	 * and then allocated an instance of Enum with the given length.
	 * It then calls the do_enumeration() method with an index of zero and number-of-ones equal to the command line argument.
	 */

	int length;
	int numOnes;
	Enum *e;

	if( argc != 3 ) usage();

  length=atoi( argv[1] );
  numOnes=atoi( argv[2] );

	e= new Enum(length);
	e->do_enumeration(0,numOnes);

	exit(0);
} //end main

