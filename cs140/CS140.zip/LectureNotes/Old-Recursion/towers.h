#include <stdio.h>
#include "dllist.h"

/* We will keep the towers in a Dllist * -- each tower is a Dllist, 
   and our Dllist * points to an array of three Dllists */

/* Move a disk from tower "from" to tower "to" */
extern make_move(Dllist *, int /* from */, int /* to */);

/* Print out the state of the towers */
extern print_towers(Dllist *);

/* Create a set of towers with a specified number of disks on tower 0 */
extern Dllist *new_towers(int);
