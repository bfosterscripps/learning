#include <stdio.h>
#include <stdlib.h>

/* Line  1 */    int *a(int *b, int **c)
/* Line  2 */    {
/* Line  3 */      int *j;
/* Line  4 */    
/* Line  5 */      *c = (*c)+1;
/* Line  6 */      **c = 25;
/* Line  7 */      printf("0x%x 0x%x 0x%x 0x%x\n", b, *b, c, *c);
/* Line  8 */      
/* Line  9 */      j = (int *) malloc(sizeof(int) * (b[0] + b[1]));
/* Line 10 */    
/* Line 11 */      return j;
/* Line 12 */    }
/* Line 13 */    
/* Line 14 */    int main()
/* Line 15 */    {
/* Line 16 */      int b[40];
/* Line 17 */      int i;
/* Line 18 */      int **c;
/* Line 19 */      int *d;
/* Line 20 */      int *j;
/* Line 21 */    
/* Line 22 */      d = b;
/* Line 23 */    
/* Line 24 */      for (i = 0; i < 40; i++)  b[i] = 10*(i+1); 
/* Line 25 */    
/* Line 26 */      c = &d;
/* Line 27 */    
/* Line 28 */      printf("0x%x 0x%x 0x%x 0x%x\n", b, &c, &d, &j);
/* Line 29 */    
/* Line 30 */      j = a(b, c);
/* Line 31 */    
/* Line 32 */      printf("0x%x 0x%x\n", j, d);
/* Line 33 */      exit(0);
/* Line 34 */    }
