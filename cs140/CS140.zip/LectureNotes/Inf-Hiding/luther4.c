#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "flcommon4.h"

void print_report(void *mi)
{
  double ns, tt;
  ns = get_ncsongs(mi);
  tt = get_tctime(mi);
  printf("<h2>Classical Music Data</h2>\n");
  printf("<UL>\n");
  printf("<LI> Total number of songs: %.0lf\n", ns);
  printf("<LI> Average song duration: %.0lf seconds: (%d:%02.0lf)\n", 
           tt/ns, ((int) (tt/ns))/60,
           tt/ns - (((int) (tt/ns))/60)*60);
  printf("</UL>\n");
}

