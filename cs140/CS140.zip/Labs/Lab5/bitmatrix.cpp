/**
 * Lab5 - bitmatrix.cpp
 *
 * Bitmatrix Class
 * 
 * Author: William McKeehan
 * Date: 02-27-2012
 */
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include "bitmatrix.h"

typedef vector <int> IVec;				//Used to build the pgm file
unsigned int djb_hash(string &s); //Implement the djb_hash - taken from lecture notes

/**
 * Create a bitmatrix of the specified size whose entries are all zeros.
 * If rows or cols is less than or equal to zero, print an error message,
 * but still create a 1 X 1 bit-matrix whose entry is zero. 
 */
Bitmatrix::Bitmatrix(int rows, int cols)
{
	int i;
	string row;
	
	if (rows <=0 || cols <= 0) {
		cerr << "Rows and columns must be larger than 0.\n";
		M.resize(1);
		M[0].resize(1);
		M[0][0] = '0';
	} else {
		row.clear();
		for( i = 0 ; i < cols ; i++ ) {
			row.push_back('0');
		}
		M.resize(rows,row);
	}
}

// Return the number of rows in the bit-matrix.
int Bitmatrix::Rows()
{
	return M.size();
}

// Return the number of columns in the bit-matrix.
int Bitmatrix::Cols()
{
	if ( M.size() > 0) {
		return M[0].size();
	} else {
		return 0;
	}
}

/**
 * Set the element in the specified row and column to the given value.
 * val can be either 0 or '0' to specify zero, and either
 * 1 or '1' to specify one. If row or col are bad, simply do nothing.
 */
void Bitmatrix::Set(int row, int col, char val)
{
	if ( row < 0 || row >= Rows() || col < 0 || col >= Cols() )
		return; //do nothing

	if( val == '0' || val == 0 )  {
		M[row][col] = '0';
	} else if( val == '1' || val == 1 ){
		M[row][col] = '1';
	}
}

/**
 * Return the specified value -- zero is 0 and one is 1.
 * Val() should return -1 if given bad input
 */
char Bitmatrix::Val(int row, int col)
{
	if ( row < 0 || row >= Rows() || col < 0 || col >= Cols() ) {
		return -1;
	} else {
		return ( M[row][col] - '0' );
	}
}

/**
 * Print the matrix on standard output. If w is less than or equal to zero,
 * print each row on its own line with no spaces. Otherwise, print a space
 * after every w columns and a blank line after every w rows.
 */
void Bitmatrix::Print(int w) 
{
	int i, j;

	for (i = 0; i < M.size(); i++) {
		if (w > 0 && i != 0 && i%w == 0) printf("\n");
		if (w <= 0) {
			cout << M[i] << endl;
		} else {
			for (j = 0; j < M[i].size(); j++) {
				if (j % w == 0 && j != 0) printf(" ");
				printf("%c", M[i][j]);
			}
			cout << endl;
		}
	}
}

/**
 * Write the bit-matrix to a file. Here, just write out the zeros and ones
 * with no spaces. Each row of the bit-matrix gets one row of output. 
 */
void Bitmatrix::Write(string fn) 
{
	ofstream f;
	int i, j;

	f.open(fn.c_str());
	if (f.fail()) {
		perror(fn.c_str());
		return;
	}

	for (i = 0; i < M.size(); i++) {
		for (j = 0; j < M[i].size(); j++) {
			f << M[i][j] ;
		}
		f << endl;
	}
}

//Swap the specified rows. This should do nothing if given bad values
void Bitmatrix::Swap_Rows(int r1, int r2)
{
	string tmp;

	if( r1 < Rows() && r1 >= 0 && r2 < Rows() && r2 >= 0 ) {
		tmp = M[r1];
		M[r1] = M[r2];
		M[r2] = tmp;
	}
}

/**
 * Set row r1 to be the sum of rows r1 and r2. Again, this should do
 * nothing if given bad values. It's ok for r2 to equal r1.
 */
void Bitmatrix::R1_Plus_Equals_R2(int r1, int r2)
{
	int i;

	if( r1 < Rows() && r1 >= 0 && r2 < Rows() && r2 >=0 ) {
		for( i = 0 ; i < M[r1].size() ; i++ )
			Set(r1,i, ( ( M[r1][i] + M[r2][i] )  % 2 ) );
	}
}

/**
 * Read a bit-matrix from a file. The file should contain only zeros,
 * ones, spaces and newlines, and each line should either be blank, or
 * it should contain the same number of non-spaces as all other lines. 
 */
Bitmatrix::Bitmatrix(string fn) 
{
	ifstream f;
	int i, j;
	string s, row;

	f.open(fn.c_str());
	if (f.fail()) { perror(fn.c_str()); M.resize(1); M[0].resize(1), M[0][0] = '0'; return; }

	while (getline(f, s)) {
		row.clear();
		for (i = 0; i < s.size(); i++) {
			if (s[i] == '0' || s[i] == '1') {
				row.push_back(s[i]);
			} else if (s[i] != ' ') {
				fprintf(stderr, "Bad matrix file %s\n", fn.c_str());
				M.resize(1); M[0].resize(1), M[0][0] = '0'; 
				f.close();
				return;
			}
		}
		if (s.size() > 0 && M.size() > 0 && row.size() != M[0].size()) {
			fprintf(stderr, "Bad matrix file %s\n", fn.c_str());
			M.resize(1); M[0].resize(1), M[0][0] = '0'; 
			f.close();
			return;
		}
		if (s.size() > 0) M.push_back(row);   
	}
	f.close();
}

/**
 * Create a PGM file from the bit-matrix.
 * The zero entries are white (255) and the one entries are gray (100).
 * Each entry is a pixel by pixel square. If border is greater than zero,
 * then there should be a black border of that many pixels separating
 * each square and around the whole matrix.
 */
void Bitmatrix::PGM(string fn, int pixels, int border)
{
	int r,c;
	ofstream f;
	int row, col, pixel, border_row, border_col, row_length;
	vector<int> colors;
	vector<IVec> p;
	IVec tmpRow;

	//Store colors in a vector to make deciding which one to use easy
	colors.push_back(255); //zero = white
	colors.push_back(100); //one = gray
	colors.push_back(0);   //black

	//total length of the row is used to build border rows
	row_length = (Cols() * pixels) + ( ( Cols() + 1 ) * border);
	
	for( row = 0 ; row < Rows() ; row++ ) {
		if( border > 0 ) {
			for( border_row = 0 ; border_row < border ; border_row++ ) {
				tmpRow.clear();
				tmpRow.resize(row_length, colors[2]);
				p.push_back(tmpRow);
			}
		}
		tmpRow.clear();
		for( col = 0 ; col < Cols() ; col++ ) {
			if( border > 0 ) {
				for( border_col = 0 ; border_col < border ; border_col++ ) {
					tmpRow.push_back(colors[2]);
				}
			}
			for( pixel = 0 ; pixel < pixels ; pixel++ ) {
				tmpRow.push_back( colors.at(Val(row, col)) );
			}
		}
		//close the row
		if( border > 0 ) {
			for( border_col = 0 ; border_col < border ; border_col++ ) {
				tmpRow.push_back(colors[2]);
			}
		}
		for( pixel = 0 ; pixel < pixels ; pixel++ ) {
			p.push_back(tmpRow);
		}
	}
	if( border > 0 ) {
		for( border_row = 0 ; border_row < border ; border_row++ ) {
			tmpRow.clear();
			tmpRow.resize(row_length, colors[2]);
			p.push_back(tmpRow);
		}
	}

	// the values for pgm are now in p, so we can easily write them out
	f.open(fn.c_str());
	if (f.fail()) {
		perror(fn.c_str());
		return;
	}

	//write the PGM header
	f << "P2\n" << p.at(0).size() << " " << p.size() << "\n255\n";

	//loop over the rows and columns, printing each cell
	for(r=0 ; r < p.size() ; r++ ) {
		for( c=0 ; c < p[r].size() ; c++) {
			f << p[r][c] << " ";
		} //end foreach col
		f << endl;
	} //end foreach row

}

/**
 * Create a new bit-matrix that is a copy of the given bit-matrix
 * and return a pointer to it. To do this, you'll have to create
 * a new empty bit-matrix of the proper size, and then use Set()
 * to set its elements properly. 
 */
Bitmatrix *Bitmatrix::Copy()
{
	int row, col;
	Bitmatrix *bm = new Bitmatrix(Rows(), Cols());

	for( row = 0 ; row < Rows() ; row++ )
		for( col = 0 ; col < Cols() ; col++ )
			bm->Set(row, col, M[row][col]);

	return bm;
}

/**
 * The constructor specifies the size of the table.
 */
BM_Hash::BM_Hash(int size)
{
	table.resize(size);
}

/**
 * Store the given key and bit-matrix in the hash table.
 * If the key is already there, replace the bit-matrix with the given one.
 */
void BM_Hash::Store(string &key, Bitmatrix *bm)
{
	unsigned int hash_index;
	int i;
	HTE *hte;

	hte = new HTE();
	hte->key = key;
	hte->bm = bm;
	hash_index = djb_hash( key ) % table.size();
	for( i = 0 ; i < table[hash_index].size() ; i++ ) {
		if( table[hash_index][i]->key == key ) {
			table[hash_index][i] = hte;
			return;
		}
	}
	table[hash_index].push_back( hte );
}

/**
 * return the bit-matrix corresponding to the given key.
 * If the key is not in the hash table, then return NULL.
 */
Bitmatrix *BM_Hash::Recall(string &key)
{
	unsigned int hash_index;
	int i;

	hash_index = djb_hash( key ) % table.size();
	for( i = 0 ; i < table[hash_index].size() ; i++ )
		if( table[hash_index][i]->key == key )
			return table[hash_index][i]->bm;

	return NULL;
}

/**
 * Return a vector of all hash table entries in the table.
 * The vector should be ordered just like the hash table.
 * In other words, suppose "A" hashes to 5, "B" hashes to
 * 1 and "C" hashes to 1. And suppose that "B" was added
 * to the table before "C". Then All() should return the
 * HTE's in the order "B", "C", "A". 
 */
HTVec BM_Hash::All()
{
	HTVec rv;
	int i, j;
	for( i = 0 ; i < table.size() ; i++ )
		for( j = 0 ; j < table[i].size() ; j++ )
			rv.push_back(table[i][j]);

	return rv;
}

/**
 * creates a new bit-matrix which is the sum of a1 and a2.
 * If a1 and a2 are not the same size, return NULL
 */
Bitmatrix *Sum(Bitmatrix *m1, Bitmatrix *m2)
{
	int row, col;
	Bitmatrix *ret;

	if( m1->Rows() != m2->Rows() || m1->Cols() != m2->Cols() ) 
		return NULL;

	ret = new Bitmatrix(m1->Rows(), m2->Cols());
	for( row = 0 ; row < m1->Rows() ; row++ )
		for( col = 0 ; col < m2->Cols() ; col++ )
			ret->Set(row,col, ( m1->Val(row,col) + m2->Val(row,col) ) % 2 );

	return ret;
}

/**
 * This creates a new bit-matrix which is the product of m1 and m2.
 * This product will have m1->Rows() rows and m2->Cols() columns.
 * If a1->Cols() and a2->Rows() do not match, then return NULL
 */
Bitmatrix *Product(Bitmatrix *m1, Bitmatrix *m2)
{
	int row, col, i, tmp;
	Bitmatrix *ret;

	if( m1->Cols() != m2->Rows() )  {
		//cerr << "Rows and Cols do not match!\n";
		return NULL;
	}

	ret = new Bitmatrix(m1->Rows(), m2->Cols());
	for( row = 0 ; row < m1->Rows() ; row++ ) {
		for( col = 0 ; col < m2->Cols() ; col++ ) {
			tmp = 0;
			for( i = 0 ; i < m1->Cols() ; i++ ) {
				tmp += m1->Val(row,i) * m2->Val(i,col);
			}
			ret->Set(row, col, tmp % 2);
		}
	}
	return ret;
}

/**
 * This creates a new bit-matrix composed of the specified rows of
 * the given bit-matrix.
 * It is ok to repeat entries in rows.
 * However, if rows is empty or contains bad indices, return NULL. 
 */
Bitmatrix *Sub_Matrix(Bitmatrix *m, vector <int> &rows)
{
	int row, col;
	Bitmatrix *ret;

	if ( rows.size() <= 0 ) return NULL;

	ret = new Bitmatrix( rows.size(), m->Cols() );
	for( row = 0 ; row < rows.size() ; row++ ) {
		if( rows[row] < 0 || rows[row] >= m->Rows() )
			return NULL;
		for( col = 0 ; col < m->Cols() ; col++ )
			ret->Set( row, col, m->Val(rows[row],col) );
	}

	return ret;
}

/**
 * Create and return the inverse of m.
 * To do this, you should also use the Swap_Rows() and R1_Plus_Equals_R2() methods.
 * If a1 is not square or not invertible, return NULL
 */
Bitmatrix *Inverse(Bitmatrix *m)
{
	int i, j, col;
	Bitmatrix *M, *Inv;
	int swapFound;

	if ( m->Rows() != m->Cols() ) return NULL;

	//Suppose you want to invert the square matrix M. What you do is
	//make a copy of M,
	M = m->Copy();
	//and create an identity matrix of the same size as M.
	Inv = new Bitmatrix( M->Rows() , M->Cols() );
	for( i = 0 ; i < M->Rows() ; i++ ) {
		Inv->Set(i,i,'1');
	}

	//You first go through each row of M from the first to the last, doing the following steps:
	for( i = 0 ; i < M->Rows() ; i++ ) {
		//If M[i][i] is not one, then find a row j where j > i such that M[i][j] equals one,
		if( M->Val(i,i) != 1 ) {
			swapFound= false;
			for( j = i + 1 ; j < M->Rows() ; j++ ) {
				if( M->Val(j,i) == 1 ) {
					//and swap rows i and j.
					swapFound= true;
					M->Swap_Rows(i,j);
					Inv->Swap_Rows(i,j);
					break;
				}
			}
			//If you can't find such a row, the matrix is not invertible.
			if ( !swapFound ) return NULL;
		}
		//Now, look at every row j such that j > i.
		for( j = i + 1 ; j < M->Rows() ; j++ ) {
			//If M[j][i] equals one,
			if( M->Val(j,i) == 1 ) {
				//then set row j equal to the sum of rows i and j. 
				for( col = 0 ; col < M->Cols() ; col++ ) {
					M->Set(j,col, ( M->Val(i,col) + M->Val(j,col) ) % 2 );
					Inv->Set(j,col, ( Inv->Val(i,col) + Inv->Val(j,col) ) % 2 );
				}
			}
		}
	}

	//Now, you start with the last row and go to the first row.
	for( i = M->Rows() - 1 ; i >= 0 ; i-- ) {
		//If there is any j > i where M[i][j] equals one, replace row i with the sum of row i and row j. 
		for( j = i + 1 ; j < M->Rows() ; j++ ) {
			if( M->Val(i,j) == 1 ) {
				//then set row j equal to the sum of rows i and j. 
				for( col = 0 ; col < M->Cols() ; col++ ) {
					M->Set(i,col, ( M->Val(i,col) + M->Val(j,col) ) % 2 );
					Inv->Set(i,col, ( Inv->Val(i,col) + Inv->Val(j,col) ) % 2 );
				}
			}
		}
	}

	return Inv;
}

/**
 * Implement the djb_hash - taken from lecture notes
 */
unsigned int djb_hash(string &s)
{
	int i;
	unsigned int h;

	h = 5381;

	for (i = 0; i < s.size(); i++) {
		h = (h << 5) + h + s[i];
	}
	return h;
}
