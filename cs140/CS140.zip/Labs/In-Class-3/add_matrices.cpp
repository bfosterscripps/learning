#include <cstdio>
#include <cstdlib>
#include <string>
#include <sstream>
#include <vector>
#include <iostream>
using namespace std;

typedef vector <double> DVec;

// Write your code here:
/**
 * Lab3-InClass - add_matricies.cpp
 *
 * Sum two matrices of doubles
 * 
 * Author: William McKeehan
 * Date: 02-01-2012
 */

//sum the contents of vector m1 and m2
int add_matrices(vector<DVec> &m1, vector<DVec> &m2, vector<DVec> &sum) {
	int i, j;

	// Check to make sure that m1 and m2 represent rectangular matrices that are the same size. If not, return 0.
	if( m1.size() == 0 || m1.size() != m2.size() ) return 0;
	for( i = 0 ; i < m1.size() ; i++ )
		if( m1[i].size() == 0 || m1[i].size() != m2[i].size() ) return 0;

	// Otherwise, it should resize sum so that it represents a rectangular matrix that is the same size as m1 and m2.
	sum.resize(m1.size());
	for( i = 0 ; i < m1.size() ; i++ )
		sum[i].resize(m1[i].size());

	// Then set its values so that it is the matrix sum of m1 and m2.
	for( i = 0 ; i < m1.size() ; i++ ) {
		for( j = 0 ; j < m1[i].size() ; j++ )
			sum[i][j] = m1[i][j] + m2[i][j];
	}

	// Then return 1. 
	return 1;
} //end add_matrices
  
// DO NOT CHANGE ANYTHING BELOW THIS LINE

main(int argc, char **argv)
{
  istringstream ss;
  int seed, r, c, i, j;
  vector <DVec> m1, m2, sum;

  if (argc != 2) {
    fprintf(stderr, "usage: add_matrices seed\n");
    exit(1);
  }

  ss.str(argv[1]);
  if (!(ss >> seed) || seed < 0) {
    fprintf(stderr, "usage: add_matrices seed\n");
    exit(1);
  }
  
  srand48(seed);
  r = lrand48()%10+1;
  c = lrand48()%13+1;
  
  m1.resize(r);
  m2.resize(r);

  for (i = 0; i < r; i++) {
    for (j = 0; j < c; j++) {
      m1[i].push_back(drand48());
      m2[i].push_back(drand48());
    }
  }
  if (lrand48()%4 == 0) {
    r = lrand48()%m1.size()+1;
    r = m1.size()-r;
    if (lrand48()%2) {
      m1.resize(r);
    } else {
      m2.resize(r);
    }
  } else if (lrand48()%4 == 0) {
    c = lrand48()%m1[0].size()+1;
    c = m1[0].size()-c;
    if (lrand48()%2) {
      for (i = 0; i < r; i++) m1[i].resize(c);
    } else {
      for (i = 0; i < r; i++) m2[i].resize(c);
    }
  } else if (lrand48()%4 == 0) {
    c = lrand48()%m1[0].size()+1;
    c = m1[0].size()-c;
    i = lrand48()%m1.size();
    if (lrand48()%2) {
      m1[i].resize(c);
    } else {
      m2[i].resize(c);
    }
  }

  if (lrand48()%4 == 0) {
    sum.resize(lrand48()%10+1);
    for (i = 0; i < sum.size(); i++) {
      c = lrand48()%12+1;
      for (j = 0; j < c; j++) sum[i].push_back(drand48());
    }
  } else if (lrand48()%4 == 0) {
    sum.resize(m1.size());
    if (m1.size() > 0) c = m1[0].size();
    for (i = 0; i < sum.size(); i++) {
      for (j = 0; j < c; j++) sum[i].push_back(drand48());
    }
  }
  
  printf("Before add_matrices:\n");

  printf("--------------\nM1:\n\n");
  for (i = 0; i < m1.size(); i++) {
    for (j = 0; j < m1[i].size(); j++) printf("%6.3lf", m1[i][j]);
    printf("\n");
  }      
  printf("--------------\nM2:\n\n");
  for (i = 0; i < m2.size(); i++) {
    for (j = 0; j < m2[i].size(); j++) printf("%6.3lf", m2[i][j]);
    printf("\n");
  }      
  printf("--------------\nSum:\n\n");
  for (i = 0; i < sum.size(); i++) {
    for (j = 0; j < sum[i].size(); j++) printf("%6.3lf", sum[i][j]);
    printf("\n");
  }      


  i = add_matrices(m1, m2, sum);
  printf("add_matrices(m1, m2, sum) = %d\n", i);

  if (!i) exit(0);

  printf("\nAfter add_matrices:\n");

  printf("--------------\nM1:\n\n");
  for (i = 0; i < m1.size(); i++) {
    for (j = 0; j < m1[i].size(); j++) printf("%6.3lf", m1[i][j]);
    printf("\n");
  }      
  printf("--------------\nM2:\n\n");
  for (i = 0; i < m2.size(); i++) {
    for (j = 0; j < m2[i].size(); j++) printf("%6.3lf", m2[i][j]);
    printf("\n");
  }      
  printf("--------------\nSum:\n\n");
  for (i = 0; i < sum.size(); i++) {
    for (j = 0; j < sum[i].size(); j++) printf("%6.3lf", sum[i][j]);
    printf("\n");
  }      
}
