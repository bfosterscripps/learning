BstreeNode *bstree_insert(Bstree *b, char *key, Jval val)
{
   BstreeNode *n;

   n = (BstreeNode *) malloc(sizeof(BstreeNode));
   if (n == NULL) { ...... }
   n->left = NULL;
   n->right = NULL;
   n->key = key;
   n->val = val;

   n = b->root;
   while (n != NULL) {
     i = strcmp(key, n->key);
     if (i == 0) return n;
     n = (i < 0) ? n->left : n->right;
   }
}


