if [ $# -ne 1 ]; then
  echo 'usage: sh eval.sh x - will do hashx' >&2
  exit 1
fi

echo '<p><center><table border=3><tr>'
echo '<td align=center>Input File</td>'
echo '<td align=center>Table Size: 4000</td>'
echo '<td align=center>Table Size: 8000</td>'
echo '<td align=center>Table Size: 100000</td></tr>'
echo '<tr><td align=center><pre>'
echo "input1.txt"
echo "input2.txt"
echo "input3.txt"
echo "input4.txt"
echo '</pre></td>'
echo '<td align=center><pre>'
hash$1 4000 < input1.txt | awk '{ print $NF"%" }'
hash$1 4000 < input2.txt | awk '{ print $NF"%" }'
hash$1 4000 < input3.txt | awk '{ print $NF"%" }'
hash$1 4000 < input4.txt | awk '{ print $NF"%" }'
echo '</pre></td>'
echo '<td align=center><pre>'
hash$1 8000 < input1.txt | awk '{ print $NF"%" }'
hash$1 8000 < input2.txt | awk '{ print $NF"%" }'
hash$1 8000 < input3.txt | awk '{ print $NF"%" }'
hash$1 8000 < input4.txt | awk '{ print $NF"%" }'
echo '</pre></td>'
echo '<td align=center><pre>'
hash$1 100000 < input1.txt | awk '{ print $NF"%" }'
hash$1 100000 < input2.txt | awk '{ print $NF"%" }'
hash$1 100000 < input3.txt | awk '{ print $NF"%" }'
hash$1 100000 < input4.txt | awk '{ print $NF"%" }'
echo '</pre></td></tr></table><b>Hash Function: 'hash$1'</b>'
echo '</center><p>'

