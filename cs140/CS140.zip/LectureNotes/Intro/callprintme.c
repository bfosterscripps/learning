#include <stdio.h>

main()
{
  printme();
  printme();
  printme();
}
