#include <stdio.h>

int fact2(int i)
{
  if (i == 0) return 1;
  return i * fact(i-1);
}

int fact(int i)
{
  int p;

  p =1;
  while (i != 0) { p *= i; i--; }
  return p;
}


main(int argc, char **argv)
{
  printf("%d\n", fact(atoi(argv[1])));
}
