#include <stdio.h>
#include <stdlib.h>

int main()
{
  char *hw = "Hello World!\n";
  int i;

  for (i = 0; hw[i] != '\0'; i++) putchar(hw[i]);
  return 0;
}
