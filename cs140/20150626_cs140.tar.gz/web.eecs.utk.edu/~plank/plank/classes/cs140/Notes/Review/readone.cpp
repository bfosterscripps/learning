#include <iostream>
using namespace std;

int main()
{
  int i;

  cin >> i;
  cout << "I is " << i << endl;

  return 0;
}
