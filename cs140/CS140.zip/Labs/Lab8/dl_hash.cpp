/**
 * Lab8 - dl_hash.cpp
 *
 * A hash table for strings
 * 
 * Author: William McKeehan
 * Date: 03-28-2012
 */

#include "dl_hash.h"
#include <cstdio>                          //for printf

using namespace std;

unsigned int djb_hash(string &s);					//Implement the djb_hash - taken from lecture notes

/**
 * Constructor that initalizes the hash table.
 */
DL_Hash::DL_Hash(int size)
{
	int i;
	for( i = 0 ; i < size ; i++ ) table.push_back( new Dlist ) ;
}

/**
 * Destructor that destroys Dlist entries that were created in the constructor phase
 */
DL_Hash::~DL_Hash()
{
	int i;
	for( i = 0 ; i < table.size() ; i++ ) delete table[i];
}

/**
 * inserts a string into the hash table. Use djb_hash() as the hash function.
 * If the string is already there, it should do nothing
 */
void DL_Hash::Insert(string &s)
{
	unsigned int djb_value;
	int table_index;
	int found;
	Dnode *d;

	djb_value = djb_hash(s);
	table_index = djb_value % table.size();

	//if the Dlist has nothing in it, the we can just add the string and be done
	if( table[table_index]->Empty() )
		return table[table_index]->Push_Back(s);

	//look at all items in the Dlist
	found = 0;
	d = table[table_index]->Begin();
	while( d != table[table_index]->End()) {
		if( d->s == s ) {
			found = 1;
			d = table[table_index]->End();
		} else {
			d = d->flink;
		}
	}

	//if we did not find this string, then we can add it
	if( !found ) {
		table[table_index]->Push_Back(s);
	}
} //end Insert

/**
 * returns whether the string is present in the hash table
 */
int DL_Hash::Present(string &s)
{
	unsigned int djb_value;
	int table_index;
	Dnode *d;

	djb_value = djb_hash(s);
	table_index = djb_value % table.size();

	//if the Dlist is empty, then it can't have the string that we're looking for
	if( table[table_index]->Empty() ) return 0;

	//look at each node in the Dlist to see if there's a match
	for(d = table[table_index]->Begin(); d != table[table_index]->End(); d = d->flink) 
		if( d->s == s ) return 1;
	
	//nothing found
	return 0;
} //end Present

/**
 * erases the string if it is there;
 * do nothing if it's not there 
 */
void DL_Hash::Erase(string &s)
{
	unsigned int djb_value;
	int table_index;
	int found;
	Dnode *d;

	found = 0;
	djb_value = djb_hash(s);
	table_index = djb_value % table.size();

	//similar to Present, if the Dlist is empty, nothing to erase
	if( table[table_index]->Empty() ) return;

	//look at each node in the Dlist to see if there's a match
	for(d = table[table_index]->Begin(); d != table[table_index]->End(); d = d->flink) 
		if( d->s == s ) return table[table_index]->Erase(d);

} //end Erase

/**
 * delete every entry in the hash table that has the given string as a substring.
 */
void DL_Hash::Strip_All_Substring(string &s)
{
	int i;
	Dnode *d;
	Dnode *next;

	//look at each Dlist
	for( i = 0 ; i < table.size() ; i++ ) {
		if( !(table[i]->Empty()) ) {
			//look at each node in the Dlist
			//can't use a for loop here because we're removing
			//items from the lis that we're traversing
			d = table[i]->Begin();
			while( d != table[i]->End() ) {
				next = d->flink; //get the next (in case we delete d)
				//delete if the substring is found in the string
				if( d->s.find(s) != -1 ) table[i]->Erase(d);
				d = next;
			}
		}
	}
} //end Strip_All_Substring

/**
 * prints out the hash table. It does this in order of hash table entry,
 * and for strings that have the same hash value, they are printed in the
 * order in which the elements were inserted into the hash table.
 *
 * The format should be one string per line, where each line contains the
 * hash index, padded to four characters and right justified, then a space
 * and then the string.
 */
void DL_Hash::Print()
{
	int i;
	Dnode *d;

	for( i = 0 ; i < table.size() ; i++ ) {
		if( !(table[i]->Empty()) ) {
			for (d = table[i]->Begin(); d != table[i]->End(); d = d->flink)
				printf( "%4d %s\n", i, d->s.c_str() );
		}
	}
} //end Print

/**
 * Implement the djb_hash - taken from lecture notes
 */
unsigned int djb_hash(string &s)
{
	int i;
	unsigned int h;

	h = 5381;

	for (i = 0; i < s.size(); i++) {
		h = (h << 5) + h + s[i];
	}
	return h;
} //end djb_hash
