void *read_music_file(char *filename);

double get_nsongs(void *mi);
double get_ttime(void *mi);
double get_ncsongs(void *mi);
double get_tctime(void *mi);
double get_nrsongs(void *mi);
double get_trtime(void *mi);
double get_nosongs(void *mi);
double get_totime(void *mi);

void print_report(void *mi);
