/* Program to read in 10 integers and print them in reverse order.  If
   the user hits EOF or enters a non-number, print out the ones read
   in already in reverse order. */

#include <stdio.h>

main()
{
  int i;
  int n[10];
  int done;

  done = 0;

  for (i = 0; i < 10 && !done; i++) {
    if (scanf("%d", &n[i]) != 1) done = 1;
  }
  if (done) i--;

  for (i--; i >= 0; i--) {
    printf("%d\n", n[i]);
  }
}
