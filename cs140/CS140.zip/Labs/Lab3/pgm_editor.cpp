#include <cstdio>
#include <cstdlib>
#include <string>
#include <sstream>
#include <vector>
#include <iostream>
using namespace std;

typedef vector <int> IVec;

// Write your code here:

/**
 * Lab3 - pgm_editor.cpp
 *
 * Write seven procedures that all revolve around PGM files, which are
 * held in a vector of vector of ints.
 *
 * The seven procedures are:
 * 1. pgm_write(p): This writes a PGM file p to standard output.
 * 2. pgm_create(r, c, pv). This creates and returns a PGM file
 *    which has r rows, c columns, and all pixels have the value pv.
 * 3. pgm_cw(p). This rotates p 90 degrees clockwise.
 * 4. pgm_ccw(p). This rotates p 90 degrees counterclockwise.
 * 5. pgm_pad(p, w, pv). This adds w pixels around the border of p.
 * 6. pgm_panel(p, r, c). This changes p so that it has r*c
 *    copies of the PGM file, laid out in a r * c grid. 
 * 7. pgm_crop(p, r, c, rows, cols). This changes p so that it has
 *    a subset of the original picture.
 * 
 * Author: William McKeehan
 * Date: 01-29-2012
 */
//writes a PGM file p to standard output
void pgm_write(vector<IVec> p)
{
	int r,c, numCells;

	//write the PGM header
	printf ("P2\n%ld %ld\n255\n", p.at(0).size(), p.size());

	//loop over the rows and columns, printing each cell
	numCells = 0;
	for(r=0 ; r < p.size() ; r++ ) {
		for( c=0 ; c < p[r].size() ; c++) {
			numCells++;
			printf("%4d", p[r][c]);
			//newline after 20 to keep output clean
			if( !(numCells%20) ) printf("\n");
		} //end foreach col
	} //end foreach row

	//print a newline if the last row did not have one
	if( (numCells%20) ) printf("\n");
} //end pgm_write

//creates and returns a PGM file which has r rows, c columns,
//and all pixels have the value pv
vector <IVec> pgm_create(int r, int c, int pv)
{
	vector<IVec> rows;
	IVec cols;

	cols.resize(c, pv);   //populate a collection of c columns with the value pv
	rows.resize(r, cols); //populate a collection of r rows with the above columns

	return rows;
} //end pgm_create

//rotates p 90 degrees clockwise.
void pgm_cw(vector<IVec> &p)
{
	int row, col, newRow, newCol, pRows, pCols;
	vector<IVec> rows;
	IVec cols;

	pRows = p.size();
	pCols = p.at(0).size();

	//create a vector with the columns and rows swapped 
	cols.resize(pRows,0);
	rows.resize(pCols, cols);

	//the first column of the last row of the original goes
	//to the first column in the first row of the new image
	//then move up the column of the original image,
	//placing succesive values in the next column of the new row
	//then move to the second column and do the same thing
	newRow = 0;
	for(col = 0 ; col < pCols ; col++ ) {
		newCol = 0;
		for(row = pRows - 1; row >= 0 ; row-- ) {
			rows[newRow][newCol] = p[row][col];
			newCol++;
		}
		newRow++;
	}

	//overwrite the given image with the rotated image
	p = rows;
} //end pgm_cw

//rotates p 90 degrees counterclockwise
void pgm_ccw(vector<IVec> &p)
{
	int row, col, newRow, newCol, pRows, pCols;
	vector<IVec> rows;
	IVec cols;

	pRows = p.size();
	pCols = p.at(0).size();

	//create a vector with the columns and rows swapped 
	cols.resize(pRows,0);
	rows.resize(pCols, cols);

	//the last column of the first row of the original goes
	//to the first column, first row of the new image
	//then move down the column of the original image,
	//placing successive values in the next column of the new row
	//then move to the next to the last colun and do the same thing
	newRow = 0;
	for(col = pCols - 1 ; col >= 0 ; col-- ) {
		newCol = 0;
		for(row = 0; row < pRows ; row++ ) {
			rows[newRow][newCol] = p[row][col];
			newCol++;
		}
		newRow++;
	}

	//overwrite the given image with the rotated image
	p = rows;
} //end pgm_ccw

//adds w pixels around the border of p. All the pixels will have the value pv
void pgm_pad(vector<IVec> &p, int w, int pv)
{
	int row, col, pRows, pCols;
	IVec cols;

	pRows = p.size();
	pCols = p.at(0).size();

	cols.resize(pCols + (w*2), pv);//create a row's worth of values
	p.resize(pRows + (w*2), cols);//add "pad" rows to the end of the table 
	
	for(row = 0 ; row < pRows ; row++ ) {
		p[row].resize(pCols + (w*2), pv); //extend the row
		for( col = pCols - 1 ; col >= 0 ; col-- ) {
			p[row][col + w] = p[row][col]; //move the data in each row to the right
		}
	}

	//move the rows down
	for( row = pRows - 1 ; row >= 0 ; row -- ) p[row + w] = p[row];

	//overwrite top rows with pad
	for( row = 0 ; row < w ; row++ ) p[row] = cols;

	//overwrite left cols with pad 
	for( row = 0 ; row < p.size() ; row++ ) {
		for( col = 0 ; col < w ; col++ ) {
			p[row][col] = pv;
		}
	}

}

//changes p so that it has r*c copies of the PGM file, laid out in a r * c grid
void pgm_panel(vector<IVec> &p, int r, int c)
{
	int row, col, pRows, pCols, nRow, nCol;
	vector<IVec> rows;
	IVec cols;

	pRows = p.size();
	pCols = p.at(0).size();

	//duplicate the image r times vertically
	for( row = 0 ; row < r ; row++ ) {
		for( nRow = 0 ; nRow < pRows ; nRow++ ) {
			cols.clear();
			//duplicate the image c times horizontally
			for( col = 0 ; col < c ; col++ ) {
				for( nCol = 0 ; nCol < pCols ; nCol++ ) {
					cols.push_back(p[nRow][nCol]);
				}
			}
			rows.push_back(cols);
		}
	}

	//overwrite the given image with the paneled image
	p = rows;
}

//changes p so that it has a subset of the original picture --
//the rectangle starting at row r and column c, with rows rows and cols cols
void pgm_crop(vector<IVec> &p, int r, int c, int rows, int cols)
{
	int row, col;
	vector<IVec> rowsvec;
	IVec colsvec;

	//start at the given row/column and add to a
	//new image the given number of rows/cols
	for( row = r ; row < r+rows ; row++ ) {
		colsvec.clear();
		for( col = c ; col < c+cols ; col++ ) {
			colsvec.push_back(p[row][col]);
		}
		rowsvec.push_back(colsvec);
	}

	//overwrite the given image with the cropped image
	p = rowsvec;
}

// DO NOT CHANGE ANYTHING BELOW THIS LINE

void bad_pgm(string s)
{
  cerr << "Bad PGM file: " << s << endl;
  exit(1);

}

vector <IVec> pgm_read()
{
  string s;
  int r, c, i, j, v;
  vector <IVec> p;

  if (!(cin >> s)) bad_pgm("Empty file.");
  if (s != "P2") bad_pgm("First word is not P2.");
  if (!(cin >> c) || c <= 0) bad_pgm("Bad column spec.");
  if (!(cin >> r) || r <= 0) bad_pgm("Bad column spec.");
  if (!(cin >> i) || i != 255) bad_pgm("Bad spec of 255.");
  p.resize(r);
  for (i = 0; i < r; i++) for (j = 0; j < c; j++) {
    if (!(cin >> v) || v < 0 || v > 255) bad_pgm("Bad pixel.");
    p[i].push_back(v);
  }
  if (cin >> s) bad_pgm("Extra stuff at the end of the file.");
  return p;
}

void usage()
{
  cerr << "usage: pgm_editor command....\n\n";
  cerr << "        CREATE rows cols pixvalue\n";
  cerr << "        CW\n";
  cerr << "        CCW\n";
  cerr << "        PAD pixels pixvalue\n";
  cerr << "        PANEL r c\n";
  cerr << "        CROP r c rows cols\n";
  exit(1);
}

main(int argc, char **argv)
{
  istringstream ss;
  int r, c, i, j, p, w, rows, cols;
  vector <IVec> pgmf;
  string a1;

  if (argc < 2) usage();
  a1 = argv[1];

  if (a1 == "CREATE") {
    if (argc != 5) usage();
    ss.clear(); ss.str(argv[2]); if (!(ss >> r) || r <= 0) usage();
    ss.clear(); ss.str(argv[3]); if (!(ss >> c) || c <= 0) usage();
    ss.clear(); ss.str(argv[4]); if (!(ss >> p) || p < 0 || p > 255) usage();
    pgmf = pgm_create(r, c, p);
  } else if (a1 == "PAD") {
    if (argc != 4) usage();
    ss.clear(); ss.str(argv[2]); if (!(ss >> w) || w <= 0) usage();
    ss.clear(); ss.str(argv[3]); if (!(ss >> p) || p < 0 || p > 255) usage();
    pgmf = pgm_read();
    pgm_pad(pgmf, w, p);
  } else if (a1 == "CCW") {
    if (argc != 2) usage();
    pgmf = pgm_read();
    pgm_ccw(pgmf);
  } else if (a1 == "CW") {
    if (argc != 2) usage();
    pgmf = pgm_read();
    pgm_cw(pgmf);
  } else if (a1 == "PANEL") {
    if (argc != 4) usage();
    ss.clear(); ss.str(argv[2]); if (!(ss >> r) || r <= 0) usage();
    ss.clear(); ss.str(argv[3]); if (!(ss >> c) || c <= 0) usage();
    pgmf = pgm_read();
    pgm_panel(pgmf, r, c);
  } else if (a1 == "CROP") {
    if (argc != 6) usage();
    ss.clear(); ss.str(argv[2]); if (!(ss >> r) || r < 0) usage();
    ss.clear(); ss.str(argv[3]); if (!(ss >> c) || c < 0) usage();
    ss.clear(); ss.str(argv[4]); if (!(ss >> rows) || rows <= 0) usage();
    ss.clear(); ss.str(argv[5]); if (!(ss >> cols) || cols <= 0) usage();
    pgmf = pgm_read();
    if (r + rows > pgmf.size() || c + cols > pgmf[0].size()) {
      fprintf(stderr, "CROP - Bad params for the pictures size (r=%d, c=%d)\n",
           (int) pgmf.size(), (int) pgmf[0].size());
      exit(1);
    }
    pgm_crop(pgmf, r, c, rows, cols);
  } else {
    usage();
  }
  pgm_write(pgmf);
}
