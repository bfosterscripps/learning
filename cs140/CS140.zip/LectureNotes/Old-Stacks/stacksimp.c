#include <stdio.h>
#include "jval.h"
#include "stack.h"

main()
{
  Jval jv;
  Stack s;

  s = new_stack();

  stack_push(s, new_jval_i(1));
  stack_push(s, new_jval_i(2));
  stack_push(s, new_jval_i(3));

  jv = stack_pop(s);
  printf("First pop: %d\n", jv.i);
  jv = stack_pop(s);
  printf("Second pop: %d\n", jv.i);
  
  stack_push(s, new_jval_i(4));

  jv = stack_pop(s);
  printf("Third pop: %d\n", jv.i);
  jv = stack_pop(s);
  printf("Fourth pop: %d\n", jv.i);
}
