/**
 * Lab6 - keno.cp
 *
 * Calculates Keno odds 
 * 
 * Author: William McKeehan
 * Date: 03-10-2012
 */
#include <iostream>     //for console input/output
#include <cstdlib>      //for exit
#include <cstdio>				//for printf

#include "product.h"

using namespace std;

int main(int argc, char **argv)
{
	double bet, payout, expected, probability;
	int balls, pballs;
	Product p;

	cin >> bet >> pballs;
	//print out the bet padded to two decimal places 
	printf( "Bet: %.2f\n", bet);
	//print the balls picked
	printf( "Balls Picked: %d\n", pballs);

	//Then for each payout, you should print the probability of winning and the expected return (probability times payout).
	expected = 0;
	while( cin >> balls >> payout ) {
		p.Clear();
		p.Multiply_Binom( 80 - pballs, 20 - balls );
		p.Multiply_Binom( pballs, balls );
		p.Divide_Binom( 80, 20 );
		probability = p.Calculate_Product();
		cout << "  Probability of catching " << balls << " of " << pballs << ": " << probability << " -- Expected return: " << (probability * payout) << endl;
		expected += (probability * payout);
	}
	expected -= bet;

	//print the expected return per bet, which is the sum of all expected returns minus the bet.
	printf( "Your return per bet: %.2f\n", expected );
	//print the normalized return, which is the expected return divided by the bet.
	printf( "Normalized: %.2f\n", expected / bet);

	exit(0);
} //end main
