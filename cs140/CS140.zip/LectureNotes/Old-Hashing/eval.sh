if [ $# -ne 1 ]; then
  echo 'usage: sh eval.sh x - will do hashx' >&2
  exit 1
fi

echo "hash $1" -- 'input1.txt - 4000 entries : ' `hash$1 1487 < input1.txt`
echo "hash $1" -- 'input2.txt - 4000 entries : ' `hash$1 4122 < input2.txt`
echo "hash $1" -- 'input3.txt - 4000 entries : ' `hash$1 2311 < input3.txt`
echo "hash $1" -- 'input4.txt - 4000 entries : ' `hash$1 8000 < input4.txt`
echo ""
echo "hash $1" -- 'input1.txt - 8000 entries : ' `hash$1 1487 < input1.txt`
echo "hash $1" -- 'input2.txt - 8000 entries : ' `hash$1 4122 < input2.txt`
echo "hash $1" -- 'input3.txt - 8000 entries : ' `hash$1 2311 < input3.txt`
echo "hash $1" -- 'input4.txt - 8000 entries : ' `hash$1 8000 < input4.txt`
echo ""

echo "hash $1" -- 'input1.txt - 100000 entries : ' `hash$1 100000 < input1.txt`
echo "hash $1" -- 'input2.txt - 100000 entries : ' `hash$1 100000 < input2.txt`
echo "hash $1" -- 'input3.txt - 100000 entries : ' `hash$1 100000 < input3.txt`
echo "hash $1" -- 'input4.txt - 100000 entries : ' `hash$1 100000 < input4.txt`
