1487 lines, 584 collisions: 39.27
4122 lines, 2682 collisions: 65.07
2311 lines, 1580 collisions: 68.37
8000 lines, 7772 collisions: 97.15

1487 lines, 493 collisions: 33.15
4122 lines, 2668 collisions: 64.73
2311 lines, 1580 collisions: 68.37
8000 lines, 7772 collisions: 97.15

1487 lines, 1477 collisions: 99.33
4122 lines, 4112 collisions: 99.76
2311 lines, 2301 collisions: 99.57
8000 lines, 7990 collisions: 99.88
