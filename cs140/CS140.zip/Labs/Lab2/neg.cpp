/**
 * Lab2 - neg.cpp
 *
 * Neg takes a PGM file on standard input, and prints a PGM file on
 * standard output that is the negative of the input file. If the PGM
 * file is not valid (same parameters as pgminfo), print an error to
 * standard error.
 * 
 * Author: William McKeehan
 * Date: 01-23-2012
 */
#include <iostream>     //for console input/output
#include <cstdlib>      //for exit
#include <cstdio>				//for printf

using namespace std;

void displayError(string errMessage); //display a error message to stderr and exit

int main(int argc, char **argv) {
	int numRows = 0;
	int numCols = 0;
	int numPixels = 0;
	int pixel = 0;
	string word = "";

	//read and validate PGM header
	if( !(cin >> word ) || word != "P2" ) displayError( "Bad PGM file -- first word is not P2" );
	if( !( cin >> numCols ) || numCols <= 0) displayError( "Bad PGM file -- No column specification" );
	if( !( cin >> numRows ) || numRows <= 0) displayError( "Bad PGM file -- No row specification" );
	if( !( cin >> pixel ) || pixel != 255) displayError( "Bad PGM file -- No 255 following the rows and columns" );

	//write the PGM header
	printf ("P2\n%d %d\n255\n", numCols, numRows);

	while( cin >> pixel ) {
		if ( numPixels >= (numRows * numCols)) displayError( "Bad PGM file -- Extra stuff after the pixels" );
		if ( pixel < 0 || pixel > 255 ) {
			cerr << "Bad PGM file -- pixel " << numPixels << " is not a number between 0 and 255\n";
			exit(1);
		} else {
			numPixels++;
			printf("%d ", 255 - pixel); // print the "negative" value
		}
	} //end while reading pixels

	exit(0);
} //end main

//display a error message to stderr and exit
void displayError(string errMessage) {
	errMessage += "\n" ;
	fprintf(stderr, "%s", errMessage.c_str() );
	exit(1);
} //end displayError
