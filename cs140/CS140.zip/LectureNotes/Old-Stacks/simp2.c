#include <stdio.h>
#include "jval.h"
#include "stack.h"

main()
{
  Stack s;

  s = new_stack();

  stack_push(s, new_jval_i(1));
  stack_push(s, new_jval_i(2));
  stack_push(s, new_jval_i(3));

  printf("First pop: %d\n", jval_i(stack_pop(s)));
  printf("Second pop: %d\n", jval_i(stack_pop(s)));
  
  stack_push(s, new_jval_i(4));

  printf("Third pop: %d\n", jval_i(stack_pop(s)));
  printf("Fourth pop: %d\n", jval_i(stack_pop(s)));
  
}
