#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <list>
using namespace std;

class DiamondHunt {
  public:
    int countDiamonds(string mine);
};

int DiamondHunt::countDiamonds(string mine)
{
  int nd, i;
  list <char> l;
  list <char>::iterator p1, p2, newp1;

  for (i = 0; i < mine.size(); i++) l.push_back(mine[i]);
  
  nd = 0;
  p1 = l.begin();
  while (p1 != l.end()) {
    if (*p1 == '>') {
      p1++;             // If p1 is not the beginning of a diamond, move on.
    } else {
      p2 = p1;
      p2++;
      if (p2 == l.end()) return nd;

      if (*p2 == '<') {   // If p2 is not the end of a diamond, move on
        p1++;
      } else {            // Otherwise, we've found a dimaond.  We need to
        nd++;             // increment nd, and set newp1 to point to the previous
                          // char, or if p1 is at the beginning, to the next one.

        if (p1 == l.begin()) {
          newp1 = p2;
          newp1++;
        } else {
          newp1 = p1;
          newp1--;
        }

        l.erase(p1);      // Now erase p1 and p2, and set p1 to newp1.
        l.erase(p2);
        p1 = newp1;
      }
    }
  }
  return nd;
}

main()
{
  DiamondHunt d;
  string s;

  while (cin >> s) {
    cout << d.countDiamonds(s) << endl;
  }
  exit(0);
}

