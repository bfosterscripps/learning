/**
 * Lab6 - product.cpp
 *
 * This represents a product as two vectors - a numerator and a denominator.
 * 
 * Author: William McKeehan
 * Date: 03-07-2012
 */
#include "product.h"

using namespace std;

/**
 * swaps the numerator and denominator
 */
void Product::Invert()
{
	int i, tmp;
	for( i= 0 ; i < numerator.size() ; i++ ) {
		tmp = numerator[i];
		numerator[i] = denominator[i];
		denominator[i] = tmp;
	}
}

/**
 * When you call Multiply_Number(i), you will make sure that numerator[i] and denominator[i] exist,
 * and then you will increment numerator[i].
 */
void Product::Multiply_Number(int n)
{
	if( n >= numerator.size() || n >= denominator.size() ) {
		numerator.resize(n+1,0);
		denominator.resize(n+1,0);
	}
	numerator[n] += 1;
}

/**
 * When you call Divide_Number(i), you will again make sure that numerator[i] and denominator[i] exist,
 * and then you will increment denominator[i].
 */
void Product::Divide_Number(int n)
{
	if( n >= numerator.size() || n >= denominator.size() ) {
		numerator.resize(n+1,0);
		denominator.resize(n+1,0);
	}
	denominator[n] += 1;
}

/**
 * Multiply by (n!).
 */
void Product::Multiply_Factorial(int n)
{
	int i;
	for( i = n ; i > 0 ; i-- )
		Multiply_Number(i);

}

/**
 * Divide by (n!).
 */
void Product::Divide_Factorial(int n)
{
	int i;
	for( i = n ; i > 0 ; i-- )
		Divide_Number(i);

}

/**
 * Multiply by binom(n,k) which is (n!)/((k!)(n-k)!)
 */
void Product::Multiply_Binom(int n, int k)
{
	Multiply_Factorial(n);
	Divide_Factorial(k);
	Divide_Factorial(n-k);
}

/**
 * Divide by binom(n,k) which is (n!)/((k!)(n-k)!)
 */
void Product::Divide_Binom(int n, int k)
{
	Divide_Factorial(n);
	Multiply_Factorial(k);
	Multiply_Factorial(n-k);
}

/**
 * clear the vectors
 */
void Product::Clear()
{
	numerator.resize(0);
	denominator.resize(0);
}

/**
 * Print() prints what the product is by printing the numerator and denominator.
 * It should cancel numbers that are in both the numerator and denominator.
 * Numbers in the numerator should be separated by spaces and asterisks, and
 * numbers in the denominator should be separated by slashes. If the numerator
 * is equal to one, print "1". If the denominator is equal to one, print nothing
 */
void Product::Print()
{
	int i, j;
	string sep;
	int one;

	//cancel numbers first
	for( i = 2 ; i < numerator.size() ; i++ ) {
		if ( numerator[i] > 0 && denominator[i] > 0) {
			if( numerator[i] >= denominator[i] ){
				numerator[i] -= denominator[i];
				denominator[i] = 0;
			} else {
				denominator[i] -= numerator[i];
				numerator[i] = 0;
			}
		}
	}

	//print numerator
	one = true;
	sep = "";
	for( i = 2 ; i < numerator.size() ; i++ ) {
		if ( numerator[i] > 0 ) {
			for( j = 0 ; j < numerator[i] ; j++ ) {
				cout << sep << i;
				one = false;
				sep = " * ";
			}
		}
	}

	if( one ) cout << "1";

	//print denominator
	sep = " / ";
	for( i = 2 ; i < denominator.size() ; i++ ) {
		if( denominator[i] > 0 ) {
			for( j = 0 ; j < denominator[i] ; j++ ) 
				cout << sep << i;
		}
	}

	cout << endl;
}

/**
 * calculate and return the product
 */
double Product::Calculate_Product()
{
	int i, j;
	double num, den;

	for( i = 2 ; i < numerator.size() ; i++ ) {
		if ( numerator[i] > 0 ) {
			if( numerator[i] >= denominator[i] ){
				numerator[i] -= denominator[i] ;
				denominator[i] = 0;
			} else {
				denominator[i] -= numerator[i] ;
				numerator[i] = 0;
			}
		}
	}

	num = 1;
	den = 1;
	for( i = 1 ; i < numerator.size() ; i++ ) {
		if ( numerator[i] > 0 ) {
			for( j = 0 ; j < numerator[i] ; j++ ) {
				num *= i;
			}
		}
	}

	for( i = 1 ; i < denominator.size() ; i++ ) {
		if( denominator[i] > 0 ) {
			for( j = 0 ; j < denominator[i] ; j++ ) 
				den *= i;
		}
	}

	if( num == 0) num =1;
	if( den == 0 ) den = 1;
	return ((double) num / (double) den);
}
