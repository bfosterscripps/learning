/**
 * Lab 1 - checkerboard
 *
 * Read five integers from standard input.
 * The first four are the parameters R, C, SC and CS.
 * The fifth parameter is a width W.
 * Your program should print out the specified checkerboard
 * such that each element of the grid is printed as a (W * W)
 * square.
 * 
 * Author: William McKeehan
 * Date: 01/19/2012
 */
#include <iostream>
#include <cstdlib>
using namespace std;

int main() {
	int R, C, CS, W;
	char SC, toprint;

	// Read five integers from standard input.
	if( cin >> R >> C >> SC >> CS >> W) {
		//exit silently if any of the parameters are less than or equal to zero
		if( R <= 0 || C <= 0 || SC <= 0 || CS <= 0 || W <= 0 ) exit(0);

		//exit silently if the ASCII value of the starting character
		//plus the cycle size is greater than 127.
		if( ( SC + CS ) > 127 ) exit(0);

		//print out the specified checkerboard
		for( int i = 0 ; i < R ; i++ )  {
			for( int j = 0 ; j < W ; j++ ) {
				for( int k = 0 ; k < C ; k++ ){
					for( int l = 0 ; l < W ; l++ ){
						//calculate the character for this row/column
						toprint = (SC + (i+k)%CS) ;
						cout << toprint;
					} //end for each W within column
				} //end foreach column
				cout << endl;
			} //end for each W within row
		} //end for each row
	} else {
		//print the same output as mine on standard error if too few arguments are
		//given, or if they are not numbers
		cerr << "usage: checkerboard  - stdin should contain R, C, SC, CS and W\n";
	} //end if read input

	exit(0);

} //end main
