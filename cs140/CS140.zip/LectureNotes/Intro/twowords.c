/* Program to read in two words and print them in reverse order */

#include <stdio.h>

main()
{
  char s1[200];
  char s2[200];

  printf("Enter two words:\n");
  if (scanf("%s", s1) != 1) exit(1);
  if (scanf("%s", s2) != 1) exit(1);
  printf("%s %s\n", s2, s1);
}
