/**
 * Lab2 - vflip.cpp
 *
 * Vflip reads a PGM file on standard input, and prints a PGM file on
 * standard output. The output file should be the vertical reflection
 * of the input file -- in other words, left is right and right is left.
 * 
 * Author: William McKeehan
 * Date: 01-23-2012
 */
#include <iostream>     //for console input/output
#include <cstdlib>      //for exit
#include <cstdio>				//for printf
#include <vector>       //for vectors

using namespace std;

void displayError(string errMessage); //display a error message to stderr and exit

int main(int argc, char **argv) {
	int numRows = 0;
	int numCols = 0;
	int numPixels = 0;
	int pixel = 0;
	vector<int> row;			//one row of pixels
	vector< vector<int> > pixels; //a collection of rows
	string word = "";

	//read and validate PGM header
	if( !(cin >> word ) || word != "P2" ) displayError( "Bad PGM file -- first word is not P2" );
	if ( !( cin >> numCols ) || numCols <= 0) displayError( "Bad PGM file -- No column specification" );
	if ( !( cin >> numRows ) || numRows <= 0) displayError( "Bad PGM file -- No row specification" );
	if ( !( cin >> pixel ) || pixel != 255) displayError( "Bad PGM file -- No 255 following the rows and columns" );

	//read each row in to a vecgtor, then add that to the pixels vector
	for( int r = 0 ; r < numRows ; r++ ) {
		row.clear();
		for( int col = 0 ; col < numCols ; col++ ) {
			if( !(cin >> pixel) ) {
					cin.clear();
					pixel = -1;
			}
			if ( pixel < 0 || pixel > 255 ) {
				cerr << "Bad PGM file -- pixel " << numPixels << " is not a number between 0 and 255\n";
				exit(1);
			} else {
				numPixels++;
				row.push_back(pixel);
			}
		} //end for each column
		pixels.push_back(row);
	} //end for each row

	//check for extra data in the input
	if( cin >> pixel ) displayError( "Bad PGM file -- Extra stuff after the pixels" );


	//now we output the flipped image
	//write the PGM header
	printf ("P2\n%d %d\n255\n", numCols, numRows);

	for( int r = numRows - 1; r >= 0; r-- ) {
		for( int c = 0; c < numCols; c++ ) {
			printf("%d\n", pixels[r][c]);
		}
	}

	exit(0);
} //end main

//display a error message to stderr and exit
void displayError(string errMessage) {
	errMessage += "\n" ;
	fprintf(stderr, "%s", errMessage.c_str() );
	exit(1);
} //end displayError
