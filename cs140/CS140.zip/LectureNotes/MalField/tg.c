#include <stdio.h>
#include "fields.h"
#include "tg.h"

TokenGen *new_tokengen(char *fn)
{
  TokenGen *tg;

  tg = (TokenGen *) malloc(sizeof(TokenGen));

  tg->is = new_inputstruct(fn);
  if (tg->is == NULL) return NULL;
  tg->field = -1;
  return tg;
}

char *tokengen_get_token(TokenGen *tg)
{
  char *s;

  while(tg->field == -1 || tg->field >= tg->is->NF) {
    if (get_line(tg->is) < 0) return NULL;
    if (tg->is->text1[0] == '#') {
      tg->field = -1;
    } else {
      tg->field = 0;
    }
  }

  s = tg->is->fields[tg->field];
  tg->field++;
  return s;
}

