#include <cstdio>
#include <iostream>
#include <sstream>
using namespace std;

typedef int Fred;

main()
{
  Fred i;

  i = 5;

  cout << "The Fred named i is equal to " << i << endl;
}
