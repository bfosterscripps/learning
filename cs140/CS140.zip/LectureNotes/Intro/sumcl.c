/* program that prints out the sum of all arguments on the 
    command line. */


#include <stdio.h>

main(int argc, char **argv)
{
  int i;
  int sum;

  sum = 0;

  for (i = 1; i < argc; i++) {
    sum += atoi(argv[i]);
  }
  printf("%d\n", sum);
}
