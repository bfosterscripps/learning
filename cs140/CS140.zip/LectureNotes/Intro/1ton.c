/* Program to print out the numbers from one to n, where the user enters n */

#include <stdio.h>

main()
{
  int i;
  int n;

  printf("Enter a number:\n");
  scanf("%d", &n);
  for (i = 1; i <= n; i++) {
    printf("%d\n", i);
  }
}
