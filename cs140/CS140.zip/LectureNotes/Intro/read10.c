/* Program to read in 10 integers and print them in reverse order */

#include <stdio.h>

main()
{
  int i;
  int n[10];

  for (i = 0; i < 10; i++) {
    if (scanf("%d", &n[i]) != 1) exit(1);
  }
  for (i = 9; i >= 0; i--) {
    printf("%d\n", n[i]);
  }
}
