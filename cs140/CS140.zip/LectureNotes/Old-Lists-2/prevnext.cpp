#include <list>
#include <iostream>
#include <cstdio>
using namespace std;

main()
{
  string s;
  list <string> l;
  list <string>::iterator lit;
  int i;

  while (getline(cin, s)) l.push_back(s);

  lit = l.begin();
  for (i = 0; i < l.size(); i++) {
    printf("Element %d:\n", i);
    if (i != 0) {
      lit--;
      printf("Previous: %s\n", lit->c_str());
      lit++;
    } 
    if (i != l.size()-1) {
      lit++;
      printf("Next:     %s\n", lit->c_str());
      lit--;
    } 
    printf("Current:  %s\n", lit->c_str());
    lit++;
    printf("\n");
  }
}
