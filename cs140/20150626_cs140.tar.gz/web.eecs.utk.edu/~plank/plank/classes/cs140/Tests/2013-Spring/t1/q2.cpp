void X(vector <double> &a)
{
  int i;

  while (!a.empty()) a.erase(a.begin());
}
