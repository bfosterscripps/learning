#include <iostream>     //for console input/output
#include <string>       //for c++ style strings

using namespace std;

class Enum {
	public:
		Enum(int length); //A constructor that takes the length of the string
		void do_enumeration(int index, int number_of_ones); //A recursive function called do_enumeration that takes an index and a number-of-ones. 

	protected:
		string s; //A string, which is initialized to have the proper length.
		int length; //The length. 
};
