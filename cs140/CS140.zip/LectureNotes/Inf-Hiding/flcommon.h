
typedef struct {
  double nsongs, ttime;
  double ncsongs, tctime;
  double nrsongs, trtime;
  double nosongs, totime;
} Music_Info;

Music_Info *read_music_file(char *filename);

