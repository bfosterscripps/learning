#include <iostream>
#include <cstdio>
using namespace std;

main()
{
  int i, j;

   for (i = 0; i <= 10; i++) {
     j = i*i;
     printf("I is %d - i*i is %d - i*2 is %d\n", i, j, i*2);
   }
}
