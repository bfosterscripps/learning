#include <list>
#include <iostream>
#include <cstdio>
using namespace std;

main()
{
  string s;
  list <string> l;
  list <string>::iterator lit;

  while (getline(cin, s)) l.push_back(s);

  l.sort();

  for (lit = l.begin(); lit != l.end(); lit++) cout << *lit << endl;
}
