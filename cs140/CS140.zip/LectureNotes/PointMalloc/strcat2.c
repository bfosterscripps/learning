#include <stdio.h>
#include <string.h>

main()
{
  char give[16];
  char him[5];
  char six[5];

  printf("give: 0x%x  him: 0x%x  six: 0x%x\n", give, him, six);

  strcpy(give, "Give");
  strcpy(him, "Him");
  strcpy(six, "Six!");

  printf("%s %s %s\n", give, him, six);

  strcpy(him, "T.J. Houshmandzadeh");

  printf("%s %s %s\n", give, him, six);

  strcat(give, " Help!");

  printf("%s %s %s\n", give, him, six);
}
