/**
 * Lab8 - dlist.cpp
 *
 * An implementation of a doubly-linked list for strings
 * 
 * Author: William McKeehan
 * Date: 03-28-2012
 */

#include "dlist.h"

/**
 * The Constructor which sets up an empty list.
 */
Dlist::Dlist()
{
	size = 0;
	sentinel = new Dnode;
	sentinel->s = "sentinel";
	sentinel->flink = sentinel;
	sentinel->blink = sentinel;
}

/**
 * destructor that removes all nodes that were created for this list
 */
Dlist::~Dlist()
{
	Dnode *tmp;
	Dnode *next;
	next = sentinel->flink;

	//delete all of the nodes that were created/added
	while( next != sentinel ) {
		tmp = next;
		next = next->flink;
		delete tmp;
	}
	//and then delete the sentinel
	delete sentinel;
}

/**
 * returns true if the list is empty; false if it's not empty
 */
int Dlist::Empty()
{
	return size == 0;
}

/**
 * returns the size of the list
 */
int Dlist::Size()
{
	return size;
}

/**
 * insert a node at the begining of the list
 */
void Dlist::Push_Front(string s)
{
	Insert_After(s, sentinel);
}

/**
 * insert a node at the end of the list
 */
void Dlist::Push_Back(string s)
{
	Insert_Before(s, sentinel);
}

/**
 * return the node from the front of the list and remove it from the list
 */
string Dlist::Pop_Front()
{
	string tmp;
	Dnode *n;

	tmp = "";
	n = sentinel->flink;
	if( n != sentinel ) {
		tmp = n->s;
		Erase(n);
	}
	return tmp;
} //end Pop Front

/**
 * return the node from the end of the list and remove it from the list
 */
string Dlist::Pop_Back()
{
	string tmp;
	Dnode *n;

	tmp = "";
	n = sentinel->blink;
	if( n != sentinel ) {
		tmp = n->s;
		Erase(n);
	}
	return tmp;
} //end Pop_Back

/**
 * return a pointer to the first node in the list
 */
Dnode *Dlist::Begin()
{
	return sentinel->flink;
}

/**
 * return the marker for the end of the list
 */
Dnode *Dlist::End()
{
	return sentinel;
}

/**
 * return the last item in the list
 */
Dnode *Dlist::Rbegin()
{
	return sentinel->blink;
}

/**
 * return the marker for the end of the list in reverse
 */
Dnode *Dlist::Rend()
{
	return sentinel;
}

/**
 * insert a node with string s before the given node n
 */
void Dlist::Insert_Before(string s, Dnode *n)
{
	Insert_After( s, n->blink );
} //end Insert_Before

/**
 * insert a node with string s after the given node n
 */
void Dlist::Insert_After(string s, Dnode *n)
{
	Dnode *newNode;

	newNode = new Dnode;
	newNode->s = s;
	newNode->flink = n->flink;
	newNode->blink = n;
	
	n->flink->blink = newNode;
	n->flink = newNode;

	size++;
} //end Insert_After

/**
 * remove the node from the list and maintain the list structure
 */
void Dlist::Erase(Dnode *n)
{
	Dnode *blink;
	Dnode *flink;

	blink = n->blink;
	flink = n->flink;

	flink->blink = blink;
	blink->flink = flink;

	delete n;
	size--;
} //end Erase
