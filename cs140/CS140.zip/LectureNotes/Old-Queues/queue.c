#include <stdio.h>
#include "queue.h"

typedef struct queue_node {
  struct queue_node *link;
  Jval val;
} Queue_Node;

typedef struct {
  int size;
  Queue_Node *front;
  Queue_Node *rear;
} True_Queue;


Queue new_queue()
{
  True_Queue *tq;

  tq = (True_Queue *) malloc(sizeof(True_Queue));
  if (tq == NULL) { perror("malloc"); exit(1); }

  tq->size = 0;
  tq->front = NULL;
  tq->rear = NULL;
  return (Queue) tq;
}

void queue_enqueue(Queue q, Jval jv)
{
  True_Queue *tq;
  Queue_Node *qn;
  
  tq = (True_Queue *) q;
  qn = (Queue_Node *) malloc(sizeof(Queue_Node));
  if (qn == NULL) { perror("malloc"); exit(1); }
  qn->link = NULL;
  qn->val = jv;
  if (tq->size == 0) {
    tq->front = qn;
    tq->rear = qn;
  } else {
    tq->rear->link = qn;
    tq->rear = qn;
  }
  tq->size++;
  return;
}

Jval queue_dequeue(Queue q)
{
  True_Queue *tq;
  Jval v;
  Queue_Node *qn;

  tq = (True_Queue *) q;
  if (tq->size == 0) {
    fprintf(stderr, "Error: queue_dequeue called on an empty queue\n");
    exit(1);
  }
  v = tq->front->val;
  qn = tq->front;
  tq->front = qn->link;
  free(qn);
  tq->size--;
  return v;
}

void free_queue(Queue q)
{
  True_Queue *tq;

  tq = (True_Queue *) q;
  while (tq->size > 0) (void) queue_dequeue(q);
  free(tq);
}

int queue_empty(Queue q)
{
  True_Queue *tq;

  tq = (True_Queue *) q;
  return (tq->size == 0);
}

int queue_size(Queue q)
{
  True_Queue *tq;

  tq = (True_Queue *) q;
  return tq->size;
}
