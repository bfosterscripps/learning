/* Program to print out the numbers from one to n where the user enters n */

#include <stdio.h>

main()
{
  int i;
  int n;

  printf("Enter a number:\n");
  if (scanf("%d", &n) != 1) exit(1);
  for (i = 1; i <= n; i++) {
    printf("%d\n", i);
  }
}
