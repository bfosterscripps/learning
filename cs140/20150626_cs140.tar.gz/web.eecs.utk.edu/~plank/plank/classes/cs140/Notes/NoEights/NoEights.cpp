#include <string>
#include <vector>
#include <list>
#include <algorithm>
#include <map>
#include <set>
#include <iostream>
#include <cstdio>
#include <cstdlib>
using namespace std;

class NoEights {
  public:
    int smallestAmount(int low, int high);
};

int NoEights::smallestAmount(int low, int high)
{
  int i;
}
