#include <iostream>
using namespace std;

int main()
{
  int i, j;

  cin >> i;
  cout << "I is " << i << endl;

  cin >> j;
  cout << "J is " << j << endl;

  return 0;
}
