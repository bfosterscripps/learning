#include <list>
#include <iostream>
#include <cstdio>
using namespace std;

bool compare(string *s1, string *s2)
{
  if (*s1 < *s2) return true;
  return false;
}

main()
{
  string s, *sp;
  list <string *> l;
  list <string *>::iterator lit, lprev;

  while (getline(cin, s)) {
    sp = new string;
    *sp = s;
    l.push_back(sp);
  }

  l.sort(compare);

  for (lit = l.begin(); lit != l.end(); lit++) {
    if (lit != l.begin()) {
      lprev = lit;
      lprev--;
      if (*(*lprev) == *(*lit)) l.erase(lprev);
    }
  }

  for (lit = l.begin(); lit != l.end(); lit++) cout << *lit << " " << *(*lit) << endl;
}
