#include <iostream>
#include <string>
using namespace std;

int main()
{
  int i;
  string s;

  i = 2;
  s = " times";

  cout << "Love me " << i << s << ", baby\n";

  return 0;
}
