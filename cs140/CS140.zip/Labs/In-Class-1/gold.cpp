#include <iostream>
using namespace std;

int main()
{
	char c;
	int sum = 0;

	while(cin>>c) {
		if( c != '.' && c != '-' ) 
			sum += c - 'A' + 1;
	}
	cout << sum << endl;

	return 0;
	
}
