#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "disjoint.h"

main()
{
   DisjointSet *dj;
   int i;

   dj = new_disjoint_set(10);
   for (i = 0; i < 10; i++) {
     disjoint_makeset(dj, i);
   }
   for (i = 0; i < 10; i++) {
     printf("Find(%d) is %d\n", i, disjoint_find(dj, i));
   }

   printf("\n");
   for (i = 2; i < 10; i+= 2) {
     disjoint_union(dj, disjoint_find(dj, 0), disjoint_find(dj, i));
   }
   for (i = 0; i < 10; i++) {
     printf("Find(%d) is %d of size %d\n", i, disjoint_find(dj, i), dj->sizes[disjoint_find(dj, i)]);
   }

}

