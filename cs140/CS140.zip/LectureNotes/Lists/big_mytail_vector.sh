cat input-3.txt \
    input-3.txt \
    input-3.txt \
    input-3.txt \
    input-3.txt \
    input-3.txt \
    input-3.txt \
    input-3.txt \
    input-3.txt \
    input-3.txt \
    input-3.txt \
    input-3.txt \
    input-3.txt \
    input-3.txt \
    input-3.txt \
    input-3.txt \
    input-3.txt \
    input-3.txt | mytail_vector > /dev/null

