if [ $# -ne 1 ]; then
  echo 'usage: sh graph-input i - does inputi.txt with 10000 lines' >&2
  exit 1
fi

for i in 1 2 3 4 5 6 8 ; do
   echo $i `hash$i 100000 < input$1.txt | awk '{ print $NF }'`
done
