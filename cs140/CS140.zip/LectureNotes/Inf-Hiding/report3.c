#include <stdio.h>
#include <stdlib.h>
#include "flcommon3.h"

main()
{
  Music_Info *mi;

  mi = read_music_file("Music.txt");

  print_report(mi);

  printf("\n");
  printf("Total number of songs (classical and non-classical): %.0lf\n", mi->nsongs);
}
