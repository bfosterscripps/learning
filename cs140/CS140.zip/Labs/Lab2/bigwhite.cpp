/**
 * Lab2 - bigwhite
 *
 * This program takes two numbers as its command line arguments --
 * the number of rows and the number of columns. It then writes a
 * PGM file on standard output which contains that number of rows
 * and columns, all of white pixels. Again, you should error check
 * to make sure that the proper number of command line arguments
 * are given, that they are integers and in the proper range.
 * On an error, print the error statement to stderr. 
 * 
 * Author: William McKeehan
 * Date: 01-24-2012
 */
#include <cstdlib>      //for exit
#include <cstdio>				//for printf
#include <sstream>      //for converting an int to a string

using namespace std;

void usage();						//display a usage message to stderr and exit

int main(int argc, char **argv) {
	istringstream ss;			//used to convert args to int
	int numRows = 0;
	int numCols = 0;

	//verify that there are enough arguments
	if ( argc != 3 ) usage();

	//convert the arguments to int
	ss.str(argv[1]);
	if (!(ss >> numRows)) usage();
	if ( numRows <= 0 ) usage();

	ss.clear();
	ss.str(argv[2]);
	if (!(ss >> numCols)) usage();
	if ( numCols <= 0 ) usage();

	//write the PGM header
	printf ("P2\n%d %d\n255\n", numCols, numRows);

	//print out a white pixel for each row/col
	for( int r = 0 ; r < numRows ; r++ ) {
		for( int c = 0 ; c < numCols ; c++ ) {
			printf( "%d ", 255);
		} //end for each column
		printf ("\n");
	} //end for each row

	exit(0);
} //end main

//display a usage message to stderr and exit
void usage() {
		fprintf(stderr, "usage: bigwhite rows cols\n");
		exit(1);
} //end usage
