/* Tokengen header file -- for reading tokens from files with comments.
   Note, you must include <stdio.h> and "fields.h" before including "tg.h" */


typedef struct {
  IS is;
  int field;
} TokenGen;

extern TokenGen *new_tokengen(char *);  /* Make a new TokenGen struct.
                                           Returns NULL on a bad filename */
extern char *tokengen_get_token(TokenGen *); /* Get a new token.  Returns
                                               NULL at EOF */
