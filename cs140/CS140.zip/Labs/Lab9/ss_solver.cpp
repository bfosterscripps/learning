/**
 * Lab9 - ss_solver.cpp
 *
 * ss_solver takes a grid on its command line, and then reads shapes
 * from standard input.
 *
 * After reading all of the shapes, it prints the solution (if there is one).
 * 
 * Author: William McKeehan
 * Date: 04-07-2012
 */
#include <cstdlib>      //for exit
#include <iostream>     //for console input/output
#include <sstream>      //for converting an int to a string
#include <stdio.h>			//required for getline
#include <string>       //for c++ style strings
#include "ShapeShifter.h"

using namespace std;

void usage()
{
	cerr << "usage: ss_solver grid-row-0 grid-row-1 ...." << endl;
	exit(1);
}

int main(int argc, char **argv)
{
	int i;
	string input_line, shape_row;
	istringstream is;
	Grid grid, shape;
	ShapeShifter *ss;

	//make sure at lest one grid row is given
	if( argc < 2 ) usage();

	//build the grid
	for( i = 1 ; i < argc ; i++ ) {
		grid.push_back(argv[i]);
	}

	//create a new ShapeShifter for the given grid;
	ss = new ShapeShifter(grid);

	//read the shapes in - each shape is on one like
	while(getline(cin,input_line) ) {
		shape.clear();
		is.clear();
		is.str(input_line);
		while(is >> shape_row) shape.push_back(shape_row);
		ss->AddShape(shape); //add this to the ShapeShifter's collection
	}

	//let the ShapeShifter provide the result if there is one
	ss->PrintSolution();

	exit(0);
} //end main
