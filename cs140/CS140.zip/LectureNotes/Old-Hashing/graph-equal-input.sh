if [ $# -ne 1 ]; then
  echo 'usage: sh graph-input i - does inputi.txt with 10000 lines' >&2
  exit 1
fi

for i in 1 2 3 4 5 6 8 9 ; do
   echo $i `head -1000 input$1.txt | hash$i 100000 | awk '{ print $NF }'`
done
