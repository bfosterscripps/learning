#include <stdio.h>
#include <stdlib.h>
#include "jpgm.h"


main(int argc, char **argv)
{
  int r, c, i, j;
  void *pgm;

  if (argc != 3
      || sscanf(argv[1], "%d", &r) != 1 || r <= 0 
      || sscanf(argv[2], "%d", &c) != 1 || c <= 0) {
    fprintf(stderr, "usage: make_shaded_pgm rows cols\n");
    exit(1);
  }
  pgm = new_black_pgm_file(r, c);

  for (i = 0; i < r; i++) {
    for (j = 0; j < c; j++) {
      pgm_set_pixel(pgm, i, j, 255*i/r);
    }
  }
  write_pgm_file(pgm, NULL);
  exit(0);
}
