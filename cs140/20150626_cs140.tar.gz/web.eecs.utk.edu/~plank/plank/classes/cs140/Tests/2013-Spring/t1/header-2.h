typedef list <double> L;
typedef vector <L *> LVec;

void print_LVec(LVec &v);

