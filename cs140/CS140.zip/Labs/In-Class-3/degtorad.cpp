#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include <iostream>
using namespace std;

// Write your code here:
/**
 * Lab3-InClass - degtorad.cpp
 *
 * convert degrees (in the form of hours, minutes and seconds to radians
 * 
 * Author: William McKeehan
 * Date: 02-01-2012
 */

const double pi = 3.141592653589793;

//convert the degrees to radians, and return the answer as a double
double degrees_to_radians( int degrees, int minutes, double seconds) {
	double rad, deg;

	//convert degrees/minutes/seconds to a decimal number
	deg = degrees + ( minutes / 60.0 ) + ( seconds / 3600. ) ;

	//convert to radians
	rad = deg * pi / 180;

	return rad;
}

// DO NOT CHANGE ANYTHING BELOW THIS LINE

main()
{
  double rad;
  int degrees, minutes;
  double seconds;
  
  while (cin >> degrees >> minutes >> seconds) {
    rad = degrees_to_radians(degrees, minutes, seconds);
    printf("%3d deg, %2d', %5.2lf\" = %7.5lf radians\n", 
         degrees, minutes, seconds, rad);
  }
}
