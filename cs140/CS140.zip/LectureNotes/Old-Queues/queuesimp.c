#include <stdio.h>
#include "jval.h"
#include "queue.h"

main()
{
  Queue q;
  int i;

  q = new_queue();

  queue_enqueue(q, new_jval_i(1));
  queue_enqueue(q, new_jval_i(2));
  queue_enqueue(q, new_jval_i(3));

  i = jval_i(queue_dequeue(q));
  printf("First dequeue: %d\n", i);
  i = jval_i(queue_dequeue(q));
  printf("Second dequeue: %d\n", i);

  queue_enqueue(q, new_jval_i(4));

  i = jval_i(queue_dequeue(q));
  printf("Third dequeue: %d\n", i);
  i = jval_i(queue_dequeue(q));
  printf("Fourth dequeue: %d\n", i);
}

