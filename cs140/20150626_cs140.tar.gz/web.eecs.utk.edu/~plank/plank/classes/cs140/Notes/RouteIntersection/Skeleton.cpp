#include <string>
#include <sstream>
#include <vector>
#include <list>
#include <algorithm>
#include <map>
#include <set>
#include <iostream>
#include <cstdio>
#include <cstdlib>
using namespace std;

class RouteIntersection {
  public:
    string isValid(int N, vector <int> coords, string moves);
};


string RouteIntersection::isValid(int N, vector <int> coords, string moves)
{
}
