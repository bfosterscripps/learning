#include <stdio.h>
#include <stdlib.h>

int main()
{
  int i;

  /* Print out numbers from 1 to 10 */

  for (i = 1; i <= 10; i++) printf("%d\n", i);

  /* Print out all the capital letters */

  for (i = 0; i < 26; i++) printf("%c", 'A'+i);
  printf("\n");

  /* Print out all the capital & lowercase letters: */

  for (i = 0; i < 26; i++) printf("%c%c", 'A'+i, 'a'+i);
  printf("\n");

  return 0;
}
