#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "fields.h"
#include "flcommon.h"

Music_Info *read_music_file(char *filename)
{
  IS is;
  int time;
  char *x;
  Music_Info *mi;

  mi = (Music_Info *) malloc(sizeof(Music_Info));
  if (mi == NULL) { perror("malloc music_info"); exit(1); }

  mi->ttime = 0;
  mi->tctime = 0;
  mi->trtime = 0;
  mi->totime = 0;
  mi->nsongs = 0;
  mi->ncsongs = 0;
  mi->nrsongs = 0;
  mi->nosongs = 0;

  is = new_inputstruct(filename);
  if (is == NULL) { perror(filename); exit(1); }

  while (get_line(is) >= 0) {
    mi->nsongs++;
    time = atoi(is->fields[1])*60;
    x = strchr(is->fields[1], ':') + 1;
    time += atoi(x);
    mi->ttime += time;
    if (strcmp(is->fields[4], "Rock") == 0) {
      mi->nrsongs++;
      mi->trtime += time;
    } else if (strcmp(is->fields[4], "Classical") == 0) {
      mi->ncsongs++;
      mi->tctime += time;
    } else {
      mi->nosongs++;
      mi->totime += time;
    }
  }
  jettison_inputstruct(is);
  return mi;
}
