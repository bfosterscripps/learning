#include <iostream>
using namespace std;

main()
{
  int i, j;

  i = 5; j = 6;
  
  cin >> i;
  cin >> j;
  printf("%d %d\n", i, j);
} 
