#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fields.h"
#include "dllist.h"

typedef struct {
  char *date;
  char *home;
  char *away;
  char *location;
  char *time;
  int differential;
} Game;

main(int argc, char **argv)
{
  IS is;
  Game *g;
  Dllist games, tmp;
  char *x;
  int i, j;
  char s[10];
  int hscore, ascore;
  int min, max;

  if (argc != 2) {
    fprintf(stderr, "usage: rug_score file\n");
    exit(1);
  }
  
  is = new_inputstruct(argv[1]);
  games = new_dllist();
  if (is == NULL) { perror(argv[1]); exit(1); }

  while (get_line(is) >= 0) {
    if (is->NF == 5) {
      if (sscanf(is->fields[0], "%d", &i) != 1 || i <= 0 || i > 31) {
        printf("%d: Date is wrong\n", is->line);
        exit(1);
      } 
      x = strchr(is->fields[0], '_');
      if (x == NULL || strlen(x) != 4) {
        printf("%d: Date is wrong\n", is->line);
        exit(1);
      }
      sprintf(s, " %s ", x+1);
      if (strstr(" Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec ", s) == NULL) {
        printf("%d: Date is wrong\n", is->line);
        exit(1);
      }
      if (strstr(is->fields[1], "_v_") == NULL) {
        printf("%d: Team names are wrong\n", is->line);
        exit(1);
      }
      x = strchr(is->fields[4], '-');
      if (x == NULL || x == is->fields[4]) {
        printf("%d: Scores are wrong\n", is->line);
        exit(1);
      }
      if (sscanf(is->fields[4], "%d", &hscore) == 0) {
        printf("%d: Scores are wrong\n", is->line);
        exit(1);
      }
      if (sscanf(x+1, "%d", &ascore) == 0) {
        printf("%d: Scores are wrong\n", is->line);
        exit(1);
      }
      g = (Game *) malloc(sizeof(Game));
      g->date = strdup(is->fields[0]);
      x = strstr(is->fields[1], "_v_");
      g->away = strdup(x+3);
      *x = '\0';
      g->home = strdup(is->fields[1]);
      g->location = strdup(is->fields[2]);
      g->time = strdup(is->fields[3]);
      g->differential = hscore - ascore;
      if (g->differential < 0) g->differential *= -1;
      dll_append(games, new_jval_v((void *) g));
    }
  }
  jettison_inputstruct(is);

  is = new_inputstruct(NULL);
  while (1) {
    printf("Enter min and max point differential: ");
    fflush(stdout);
    if (get_line(is) < 0) exit(0);
    if (is->NF == 2 && sscanf(is->fields[0], "%d", &min) == 1 &&
                       sscanf(is->fields[1], "%d", &max) == 1) {
      dll_traverse(tmp, games) {
        g = (Game *) tmp->val.v;
        if (g->differential <= max && g->differential >= min) {
          printf("%s v %s on %s/%s at %s\n", g->home, g->away, g->date, g->time, g->location);
        }
      }
    } else {
      if (is->NF != 0) printf("Bad min & max:\n");
    }
  }
}
