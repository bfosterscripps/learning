#include <iostream>
using namespace std;

main()
{
  double i, j;

  i = 5.89; j = 6;
  
  cin >> i;
  cin >> j;
  printf("%.1lf %.1lf\n", i, j);
} 
