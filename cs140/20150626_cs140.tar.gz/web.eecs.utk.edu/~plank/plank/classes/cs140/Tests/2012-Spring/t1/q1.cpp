#include <iostream>
using namespace std;

main()
{
  cout << "Luigi";
  cerr << "Binky";
  cout << "Thor";
  cout << endl;
  cerr << endl;
}
