#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "flcommon.h"

main()
{
  Music_Info *mi;

  mi = read_music_file("Music.txt");
  mi->nsongs = mi->ncsongs;
  mi->ttime = mi->tctime;
  printf("<h2>Classical Music Data</h2>\n");
  printf("<UL>\n");
  printf("<LI> Total number of songs: %.0lf\n", mi->nsongs);
  printf("<LI> Average song duration: %.0lf seconds: (%d:%02.0lf)\n", 
           mi->ttime/mi->nsongs, ((int) (mi->ttime/mi->nsongs))/60,
           mi->ttime/mi->nsongs - (((int) (mi->ttime/mi->nsongs))/60)*60);
  printf("</UL>\n");
}
