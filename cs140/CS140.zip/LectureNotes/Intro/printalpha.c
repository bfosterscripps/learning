/* program that prints out all the lower case letters in order,
    all on one line, using a for loop. */


#include <stdio.h>

main()
{
  int i;

  for (i = 'a'; i <= 'z'; i++) {
    printf("%c", i);
  }
  printf("\n");
}
