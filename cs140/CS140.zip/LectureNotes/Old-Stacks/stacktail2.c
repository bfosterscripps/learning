#include <stdio.h>
#include <string.h>
#include "jval.h"
#include "stack.h"
#include "fields.h"

main(int argc, char **argv)
{
  IS is;
  Stack *s, *s2;
  Jval j;
  int nl, i;

  /* Get the number of lines */

  if (argc != 2) {
    fprintf(stderr, "usage: stacktail n\n");
    exit(1);
  }
  nl = atoi(argv[1]);
  if (nl <= 0) exit(0);

  /* Intialize stack and input */

  s = new_stack();
  is = new_inputstruct(NULL);

  /* Push each line onto the stack */

  while (get_line(is) >= 0) {
    stack_push(s, new_jval_s(strdup(is->text1)));
  }

  /* Set nl to be the min of the given nl and 
     the number of lines in standard input. */

  if (stack_size(s) < nl) nl = stack_size(s);
  if (nl == 0) exit(0);
 
  /* Allocate a second stack, and push on the last nl elements */

  s2 = new_stack();

  for (i = 0; i < nl; i++) {
    stack_push(s2, stack_pop(s));
  }

  /* Print out the lines by popping them off the second stack */

  while (!stack_empty(s2)) {
    j = stack_pop(s2);
    printf("%s", j.s);
  }
}
