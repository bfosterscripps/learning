#include <list>
#include <iostream>
#include <cstdio>
using namespace std;

main()
{
  string s;
  list <string> l;
  list <string>::iterator lit, lnext;
  int doerase;

  while (getline(cin, s)) l.push_back(s);

  l.sort();

  for (lit = l.begin(); lit != l.end(); ) {
    lnext = lit;
    lnext++;
    if (lnext != l.end() && *lnext == *lit) {
      l.erase(lnext);
    } else {
      lit++;
    }
  }

  for (lit = l.begin(); lit != l.end(); lit++) cout << *lit << endl;
}
