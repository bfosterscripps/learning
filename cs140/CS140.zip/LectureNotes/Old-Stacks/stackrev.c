#include <stdio.h>
#include <string.h>
#include "jval.h"
#include "stack.h"
#include "fields.h"

main()
{
  IS is;
  Stack *s;

  s = new_stack();
  is = new_inputstruct(NULL);

  while (get_line(is) >= 0) {
    stack_push(s, new_jval_s(strdup(is->text1)));
  }

  while (!stack_empty(s)) {
    printf("%s", jval_s(stack_pop(s)));
  }
}

