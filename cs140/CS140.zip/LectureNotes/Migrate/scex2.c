#include <stdio.h>
#include <stdlib.h>

int main()
{
  int i;
  int n;

  n = 1;
  while (1) {
    if (scanf("%d", &i) != 1) return 0;
    printf("Integer %d. %d\n", n, i);
    n++;
  }
}
