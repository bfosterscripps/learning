#include <stdio.h>
#include "perm_table.h"
#include <stdlib.h>
#include <string.h>
#include "fields.h"


int string_equal(char *s1, char *s2)
{
  int i;

  for (i = 0; s1[i] == s2[i] && s1[i] != '\0'; i++) ;
  return (s1[i] == s2[i]);
}
 
int hash_string_8(s)
char *s;
{
  int i;
  unsigned char h, tmp;
  
  h = 0;
  i = 0;

  while (s[i] != '\0') {
    tmp = s[i];
    h = perm_table[h ^ tmp];
    i++;
  }
  return h;
}

int hash_string_16(s)
char *s;
{
  char c;
  unsigned char h1, h2;

  if (s[0] == '\0') return 0;
  c = s[0];
  h1 = hash_string_8(s);
  s[0] = (c + 1) % 256;
  h2 = hash_string_8(s);
  s[0] = c;
  return (h1 << 8) | h2;
}

int hash_string_32(s)
char *s;
{
  char c;
  unsigned char h1, h2;

  if (s[0] == '\0') return 0;
  c = s[0];
  h1 = hash_string_8(s);
  s[0] = (c + 1) % 256;
  h2 = hash_string_8(s);
  h1 = (h1 << 8) | h2;
  s[0] = (c + 2) % 256;
  h2 = hash_string_8(s);
  h1 = (h1 << 8) | h2;
  s[0] = (c + 3) % 256;
  h2 = hash_string_8(s);
  s[0] = c;
  return (h1 << 8) | h2;
}

int bytes_equal(s1, s2, n)
char *s1, *s2;
int n;
{
  int i;

  for (i = 0; i < n && s1[i] == s2[i]; i++) ;
  return (i < n);
}

int hash_bytes_8(s, n)
char *s;
int n;
{
  int i;
  unsigned char h, tmp;

  h = 0;

  for(i = 0; i < n; i++) {
    tmp = s[i];
    h = perm_table[h ^ tmp];
  }
  return h;
}

int hash_bytes_16(s, n)
char *s;
int n;
{
  char c;
  unsigned char h1, h2;

  if (s[0] == '\0') return 0;
  c = s[0];
  h1 = hash_bytes_8(s, n);
  s[0] = (c + 1) % 256;
  h2 = hash_bytes_8(s, n);
  s[0] = c;
  return (h1 << 8) | h2;
}

int hash_bytes_32(s, n)
char *s;
{
  char c;
  unsigned char h1, h2;

  if (s[0] == '\0') return 0;
  c = s[0];
  h1 = hash_bytes_8(s, n);
  s[0] = (c + 1) % 256;
  h2 = hash_bytes_8(s, n);
  h1 = (h1 << 8) | h2;
  s[0] = (c + 2) % 256;
  h2 = hash_bytes_8(s, n);
  h1 = (h1 << 8) | h2;
  s[0] = (c + 3) % 256;
  h2 = hash_bytes_8(s, n);
  s[0] = c;
  return (h1 << 8) | h2;
}


main(int argc, char **argv)
{
  IS is;
  int table_size;
  int *hashes;
  int h;
  double ncollisions;
  double nl;

  ncollisions = 0;
  nl = 0;

  if (argc != 2) {
    fprintf(stderr, "usage: hash2 table_size\n");
    exit(1);
  }
  table_size = atoi(argv[1]);
  if (table_size <= 0) {
    fprintf(stderr, "usage: hash2 table_size (> 0)\n");
    exit(1);
  }

  hashes = (int *) malloc(sizeof(int) * table_size);
  if (hashes == NULL) { perror("malloc"); }
  for (h = 0; h < table_size; h++) hashes[h] = 0;

  is = new_inputstruct(NULL);

  while(get_line(is) >= 0) {
    nl++;
    is->text1[strlen(is->text1)-1] = '\0';
    h = hash_string_32(is->text1) % table_size;
    if (hashes[h] != 0) ncollisions++;
    hashes[h]++;
  }
  printf("%.0lf lines, %.0lf collisions: %.2lf\n", nl, 
         ncollisions, ncollisions * 100.0 / nl);
}
