#include <iostream>
using namespace std;

main()
{
  cout << "Writing this to cout.\n";
  cerr << "Writing this to cerr.\n";
}
