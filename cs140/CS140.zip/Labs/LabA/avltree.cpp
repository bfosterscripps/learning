/**
 * LabA - AVLTree
 *
 * An implementation of an AVL balanced tree class
 * 
 * Author: William McKeehan
 * Date: 04/21/2012
 */
#include <iostream>
#include <vector>
#include <cstdlib>
#include <cstdio>
#include "avltree.h"
using namespace std;

/**
 * Constructor - taken from lecture notes on btrees
 * added heigh
 */
AVLTree::AVLTree()
{
	sentinel = new AVLTNode;
	sentinel->left = sentinel;
	sentinel->right = sentinel;
	sentinel->height = -1;
	size = 0;
}

/**
 * Destructor - taken from lecture notes on btrees
 */
AVLTree::~AVLTree()
{
	recursive_destroy(sentinel->right);
	delete sentinel;
}

/**
 * Insert a new node into the tree and make sure it's balanced.
 * taken from lecture notes on btrees
 */
int AVLTree::Insert(string s, void *val)
{
	AVLTNode *parent;
	AVLTNode *n;

	parent = sentinel;
	n = sentinel->right;

	while (n != sentinel) {
		if (n->key == s) return 0;
		parent = n;
		if (s < n->key) {
			n = n->left;
		} else {
			n = n->right;
		}
	}

	n = new AVLTNode;
	n->height = 0;
	n->key = s;
	n->val = val;
	n->parent = parent;
	n->left = sentinel;
	n->right = sentinel;
	if (parent == sentinel) {
		sentinel->right = n;
	} else if (s < parent->key) {
		parent->left = n;
	} else {
		parent->right = n;
	}
	size++;
	Check_Balance(n->parent);
	return 1;
} //end Insert

/**
 * Find a given node in the tree
 * taken from lecture notes on btrees
 */
void *AVLTree::Find(string s)
{
	AVLTNode *n;

	n = sentinel->right;
	while (1) {
		if (n == sentinel) return NULL;
		if (s == n->key) return n->val;
		if (s < n->key) {
			n = n->left;
		} else {
			n = n->right;
		}
	}
} //end Find

/**
 * Delete a note with the given key from the tree - and rebalance
 * taken from lecture notes on btrees
 */
int AVLTree::Delete(string s)
{
	AVLTNode *n, *parent, *mlc;
	string tmpkey;
	void *tmpval;

	n = sentinel->right;
	while (n != sentinel && s != n->key) {
		if (s < n->key) {
			n = n->left;
		} else {
			n = n->right;
		}
	}
	if (n == sentinel) return 0;

	parent = n->parent;
	if (n->left == sentinel) {
		if (n == parent->left) {
			parent->left = n->right;
		} else {
			parent->right = n->right;
		}
		if (n->right != sentinel) n->right->parent = parent;
		delete n;
		size--;
	} else if (n->right == sentinel) {
		if (n == parent->left) {
			parent->left = n->left;
		} else {
			parent->right = n->left;
		}
		n->left->parent = parent;
		delete n;
		size--;
	} else {
		for (mlc = n->left; mlc->right != sentinel; mlc = mlc->right) ;
		tmpkey = mlc->key;
		tmpval = mlc->val;
		Delete(tmpkey);
		n->key = tmpkey;
		n->val = tmpval;
		Check_Balance(n);
	}
	Check_Balance(parent);
	return 1;
}//end Delete

/**
 * Sorted_Vector - taken from lecture notes on btrees
 */
vector <void *>AVLTree::Sorted_Vector()
{
	array.clear();
	recursive_make_vector(sentinel->right);
	return array;
}

/**
 * Print - taken from lecture notes on btrees
 */
void AVLTree::Print()
{
	recursive_inorder_print(0, sentinel->right);
}

/**
 * Size - taken from lecture notes on btrees
 */
int AVLTree::Size()
{
	return size;
}

/**
 * Empty - taken from lecture notes on btrees
 */
int AVLTree::Empty()
{
	return (size == 0);
}

/**
 * recursive_inorder_print - taken from lecture notes on btrees
 * added the height to the print out
 */
void AVLTree::recursive_inorder_print(int level, AVLTNode *n)
{
	if (n == sentinel) return;
	recursive_inorder_print(level+2, n->right);
	printf("%*s%d %s\n", level, "", n->height, n->key.c_str());
	recursive_inorder_print(level+2, n->left);
}

/**
 * recursive_make_vector - taken from lecture notes on btrees
 */
void AVLTree::recursive_make_vector(AVLTNode *n)
{
	if (n == sentinel) return;
	recursive_make_vector(n->left);
	array.push_back(n->val);
	recursive_make_vector(n->right);
}

/**
 * recursive_destroy - taken from lecture notes on btrees
 */
void AVLTree::recursive_destroy(AVLTNode *n)
{
	if (n == sentinel) return;
	recursive_destroy(n->left);
	recursive_destroy(n->right);
	delete n;
}

/**
 * Check_Balance will set the height of node n,
 * and then to set n equal to Rebalance(n).
 * If the new height of n is different from its
 * old height, then continue checking n->parent.
 */
void AVLTree::Check_Balance(AVLTNode *n)
{
	int oldHeight;

	if( n == sentinel ) return;

	//Its job is to set the height of node n,
	oldHeight = n->height;
	n->height = max(n->left->height, n->right->height) + 1;
	//and then to set n equal to Rebalance(n).
	n = Rebalance(n);
	//If the new height of n is different from its old height, then it should continue checking n->parent. If not, it can return. 
	if( oldHeight != n->height )
		Check_Balance(n->parent);

	return;
}//end Check_Balance

/**
 * Rebalance the given subtree by properly identifying and performing
 * the type of rebalance (Zig-Zig or Zig-Zag), and then returning the
 * root of the new subtree. 
 */
AVLTNode *AVLTree::Rebalance(AVLTNode *n)
{
	int balanced;
	AVLTNode *newRoot;

	balanced = ( abs(n->left->height - n->right->height) < 2) ;
	if( balanced ) return n; //If it is balanced just return n.

	//rebalance by properly identifying and performing the type of rebalance
	//(Zig-Zig or Zig-Zag)
	if( n->left->height == n->height - 1) {
		if( n->left->left->height == n->height - 2 ) {
			newRoot = n->left;
			//Zig-Zig
			Rotate(n->left);
		} else {
			//Zig-Zag
			//cout << "Zig-Zag\n";
			Rotate(n->left->right);
			newRoot = n->left;
			Rotate(n->left);
		}
	} else {
		//n->right->height == n->height - 1
		if( n->right->right->height == n->height - 2 ) {
			newRoot = n->right;
			//Zig-Zig
			Rotate(n->right);
		} else {
			//Zig-Zag
			Rotate(n->right->left);
			newRoot = n->right;
			Rotate(n->right);
		}
	}

	//return the root of the new subtree
	return newRoot;
} //end Rebalance

/**
 * Rotate about node n, updating all pointers and heights of all relevant nodes
 */
void AVLTree::Rotate(AVLTNode *d)
{
	int i;
	AVLTNode *a, *b, *c, *parent;

	b = d->parent;
	parent = b->parent;
	if( b->left == d ) {
		c = d->right;
		b->left = c;
		c->parent = b;
		d->right = b;
	} else { //b->right == d
		c = d->left;
		b->right = c;
		c->parent = b;
		d->left = b;
	}

	b->parent = d;
	d->parent = parent;
	if( parent->left == b ) {
		parent->left = d;
	} else {
		parent->right = d;
	}

	//update the heights
	b->height = max(b->left->height, b->right->height) + 1;
	d->height = max(d->left->height, d->right->height) + 1;

} //end Rotate

