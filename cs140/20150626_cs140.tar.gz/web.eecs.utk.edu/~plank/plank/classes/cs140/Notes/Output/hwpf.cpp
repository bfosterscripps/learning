#include <iostream>
#include <cstdio>
using namespace std;

main()
{
  printf("Hello world\n");
}
