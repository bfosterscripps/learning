#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "fields.h"

main()
{
  IS is;
  int time;
  char *x;
  double nsongs, ttime;
  double ncsongs, tctime;
  double nrsongs, trtime;
  double nosongs, totime;

  ttime = 0;
  tctime = 0;
  trtime = 0;
  totime = 0;
  nsongs = 0;
  ncsongs = 0;
  nrsongs = 0;
  nosongs = 0;

  is = new_inputstruct(NULL);

  while (get_line(is) >= 0) {
    nsongs++;
    time = atoi(is->fields[1])*60;
    x = strchr(is->fields[1], ':') + 1;
    time += atoi(x);
    ttime += time;
    if (strcmp(is->fields[4], "Rock") == 0) {
      nrsongs++;
      trtime += time;
    } else if (strcmp(is->fields[4], "Classical") == 0) {
      ncsongs++;
      tctime += time;
    } else {
      nosongs++;
      totime += time;
    }
  }
  
  printf("Total Songs: %5.0lf   Avg Duration: %7.2lf\n", nsongs, ttime/nsongs);
  printf("Rock  Songs: %5.0lf   Avg Duration: %7.2lf\n", nrsongs, trtime/nrsongs);
  printf("Class Songs: %5.0lf   Avg Duration: %7.2lf\n", ncsongs, tctime/ncsongs);
  printf("Other Songs: %5.0lf   Avg Duration: %7.2lf\n", nosongs, totime/nosongs);
}
