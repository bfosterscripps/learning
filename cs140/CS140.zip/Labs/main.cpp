/**
 * LABNUM - PROGTITLE
 *
 * descr
 * 
 * Author: William McKeehan
 * Date: TODAY
 */
#include <cmath>        //for sqrt
#include <cstdlib>      //for exit
#include <cstdio>				//for printf
#include <fstream>      //for file input/output
#include <iomanip>      //for formatting output with setw and setprecision
#include <iostream>     //for console input/output
#include <sstream>      //for converting an int to a string
#include <stdio.h>			//required for getline
#include <string>       //for c++ style strings
#include <vector>       //for vectors

using namespace std;

int main(int argc, char **argv) {

	exit(0);
} //end main
