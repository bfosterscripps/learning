#include <list>
#include <iostream>
#include <cstdio>
using namespace std;

main()
{
  string s;
  list <string> l;
  list <string>::iterator lit, lnext;

  while (getline(cin, s)) l.push_back(s);

  l.sort();

  for (lit = l.begin(); lit != l.end(); lit++) {
    lnext = lit;
    lnext++;
    if (lnext != l.end() && *lnext == *lit) l.erase(lnext);
  }

  for (lit = l.begin(); lit != l.end(); lit++) cout << *lit << endl;
}
