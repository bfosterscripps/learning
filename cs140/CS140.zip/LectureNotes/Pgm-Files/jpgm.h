/* jpgm.h
 * Jim Plank
 * CS140 - Data Structures
 * September, 2006
 */

/* Data structure for reading/writing/modifying PGM files.  Note, the PGM
   files are passed back and forth as (void *)'s, which means that the user
   of this data structure knows nothing about its implementation, other than
   the fact that it should work. */

void *read_pgm_file(char *filename);            /* Read a PGM file into the data structure
                                                   and return it.  NULL reads from stdin  */

void *new_black_pgm_file(int rows, int cols);   /* Create a new black PGM file */

void write_pgm_file(void *pgm, char *filename); /* Write the PGM file to a file (NULL for stdout) */

int pgm_rows(void *pgm);                        /* Get the number of rows in the PGM file */
int pgm_cols(void *pgm);                        /* Get the number of columns in the PGM file */

int pgm_get_pixel(void *pgm, int r, int c);         /* Get the value of a pixel */

void pgm_set_pixel(void *pgm, int r, int c, int value);  /* Set the value of a pixel */

void jettison_pgm(void *pgm);                   /* Call free() on relevant pointers */
