/**
 * Lab2 - pgminfo.cpp
 *
 * Your first PGM program should take a PGM file on standard input
 * and report the number of rows, the number of columns, the total
 * number of pixels, and the average value of all the pixels, padded
 * to three decimal places. Your program should work on all valid
 * PGM files, and should print out an error (using cerr) on any
 * invalid PGM file.
 * 
 * Examples of invalid PGM files are:
 *	Those that don't begin with P2.
 *  Those that don't have non-negative integers after the P2.
 *  Those that don't have the number 255 after the number of rows and columns.
 *  Those that contain the wrong number of pixels after the P2. This includes having too many pixels.
 *  Those that contain pixels whose values are not numbers between 0 and 255. 
 * 
 * Author: William McKeehan
 * Date: 01-23-2012
 */
#include <iostream>     //for console input/output
#include <cstdlib>      //for exit
#include <cstdio>				//for printf

using namespace std;

void displayError(string errMessage); //display a error message to stderr and exit

int main(int argc, char **argv) {
	int numRows = 0;
	int numCols = 0;
	int numPixels = 0;
	int totalPixelValue = 0;
	int pixel = 0;
	string word = "";

	//read and validate PGM header
	if( !(cin >> word ) || word != "P2" ) displayError( "Bad PGM file -- first word is not P2" );
	if( !( cin >> numCols ) || numCols <= 0) displayError( "Bad PGM file -- No column specification" );
	if( !( cin >> numRows ) || numRows <= 0) displayError( "Bad PGM file -- No row specification" );
	if( !( cin >> pixel ) || pixel != 255) displayError( "Bad PGM file -- No 255 following the rows and columns" );

	//read all pixels
	while( cin >> pixel ) {
		if ( numPixels >= (numRows * numCols)) displayError( "Bad PGM file -- Extra stuff after the pixels" );
		if ( pixel < 0 || pixel > 255 ) {
			cerr << "Bad PGM file -- pixel " << numPixels << " is not a number between 0 and 255\n";
			exit(1);
		} else {
			numPixels++;
			totalPixelValue += pixel;
		}
	}

	//display the desired outcome
	printf( "# Rows: %11d\n", numRows);
	printf( "# Columns: %8d\n", numCols);
	printf( "# Pixels: %9d\n", numPixels);
	printf( "Avg Pixel: %8.3f\n", ( (double)totalPixelValue / numPixels));

	exit(0);
} //end main

//display a error message to stderr and exit
void displayError(string errMessage) {
	errMessage += "\n" ;
	fprintf(stderr, "%s", errMessage.c_str() );
	exit(1);
} //end displayError
