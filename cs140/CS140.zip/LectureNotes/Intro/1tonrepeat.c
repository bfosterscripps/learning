/* Program to print out the numbers from one to n repeatedly */

#include <stdio.h>

main()
{
  int i;
  int n;
  int ok;

  while (1) {
    printf("Enter a number:\n");
    if (scanf("%d", &n) != 1) exit(0);
    for (i = 1; i <= n; i++) {
      printf("%d\n", i);
    }
  }
}
