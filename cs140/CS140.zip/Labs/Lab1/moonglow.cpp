/**
 * 
 * Lab 1 - moonglow
 * Read a file in Moonglow's format on standard input, and print a very simple output.
 *
 * Moonglow's format: The text file is composed of words. If a word is a number, then
 * that is a student's score on a question, so you add it to the student's exam score.
 * If the word is not a number, but is the word "NAME", then the next word is the
 * student's name (Moonglow only uses first names -- last names are corporate and
 * impersonal). If the word is "AVERAGE", then you start reading numbers until you
 * read a word that is not a number (or is the end of the file). You average all of
 * those numbers and add that to the score. Since Moonglow is a little scatterbrained,
 * sometimes a number does not follow "AVERAGE." In that case, you ignore the "AVERAGE".
 *
 * When you are done reading the file, your program should print the student's name,
 * a space, and the student's score. Just use cout for this -- nothing exciting.
 *
 * Error Checking:
 * The input will specify exactly one student's name.
 * That student's name won't be "AVERAGE" or "NAME." 
 *
 * Author: William McKeehan
 * Date: 01/19/2012
 */
#include <iostream>
#include <cstdlib>
using namespace std;


int main() {
	double n;
	string s;
	string name = "";
	bool avg = false;
	int avgCount = 0;
	double avgTotal = 0.0;
	double examScore = 0.0;

	//Read the entire file
	while ( !cin.eof() ) {
		//if we read a number
		if(cin>>n) {
			//if we are in "AVERAGE" mode, then add this to the average total 
			if(avg) {
				avgTotal += n;
				avgCount++;	
			} else {
				//else, just add this to the exam score
				examScore += n;
			}
		} else {
			//we read something that is not a number
			//if we are in average mode and have something to average
			if(avg && avgCount != 0) {
				//add the average of our current runnint total to the examScore
				examScore += ( avgTotal / avgCount );
			}
			//not a number, so stop with the average
			avg = false;
			cin.clear(); //clear the error
			//and read the input as a string
			if(cin>>s) {
				//if we have read the string "NAME"
				if( s == "NAME" ) {
					//then read the next word
					//into the name variable
					cin >> name ;
				} else if( s == "AVERAGE" ) {
					//if we have the word "AVERAGE", then switch into average mode
					//and reset our average counters
					avg = true;
					avgCount = 0;
					avgTotal = 0.0;
				}
			} else {
				//eof has been encountered
			}
		} //end else not a number
	} //end while !cin.eof

	//print the student's name, a space, and the student's score
	cout << name << " " << examScore << endl;

	exit(0);
} //end main
