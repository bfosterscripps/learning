#include <stdio.h>
#include <stdlib.h>
#include "jpgm.h"
#include "fields.h"

#define talloc(type, num) (type *) malloc(sizeof(type)*(num))

typedef struct {
  int rows;
  int cols;
  int **pixels;
} Pgm;

void *new_black_pgm_file(int rows, int cols)
{
  Pgm *p;
  int i, j;

  p = talloc(Pgm, 1);
  if (p == NULL) { return NULL; }

  p->rows = rows;
  p->cols = cols;
 
  p->pixels = talloc(int *, p->rows);
  if (p->pixels == NULL) { return NULL; }
  for (i = 0; i < p->rows; i++) {
    p->pixels[i] = talloc(int, p->cols);
    if (p->pixels[i] == NULL) { return NULL; }
    for (j = 0; j < p->cols; j++) p->pixels[i][j] = 0;
  }
  return (void *) p;
}

void write_pgm_file(void *pgm, char *filename)
{
  FILE *f;
  Pgm *p;
  int i, j;

  if (filename == NULL) {
    f = stdout;
  } else {
    f = fopen(filename, "w");
    if (f == NULL) { perror(filename); exit(1); }
  }

  p = (Pgm *) pgm;

  fprintf(f, "P2\n%d %d\n255\n", p->cols, p->rows);

  for (i = 0; i < p->rows; i++) {
    for (j = 0; j < p->cols; j++) {
      fprintf(f, "%d\n", p->pixels[i][j]);
    } 
  }

  if (filename != NULL) fclose(f);
}

int pgm_get_pixel(void *pgm, int r, int c)
{
  Pgm *p;

  p = (Pgm *) pgm;

  if (r < 0 || r >= p->rows ||  c < 0 || c >= p->cols) return -1;
  return (p->pixels[r][c]);
}

void pgm_set_pixel(void *pgm, int r, int c, int value)
{
  Pgm *p;

  p = (Pgm *) pgm;

  if (r < 0 || r >= p->rows ||  c < 0 || c >= p->cols) return;
  if (value < 0 || value > 255) return;
  p->pixels[r][c] = value;
}

void *read_pgm_file(char *filename)
{
  Pgm *p;
  IS is;
  int r, c, pixel, i;
  int state;

  is = new_inputstruct(filename);
  if (is == NULL) { perror(filename); return NULL; }
  state = 0;

  while (get_line(is) >= 0) {
    if (is->NF > 0 && is->fields[0][0] == '#') {
    } else if (state == 0) {
      if (is->NF != 1 || strcmp(is->fields[0], "P2") != 0) {
        fprintf(stderr, "PGM File - first line not P2\n");
        return NULL;
      }
      state++;
    } else if (state == 1) {
      if (is->NF != 2 || sscanf(is->fields[1], "%d", &r) != 1 || r < 0 ||
                             sscanf(is->fields[0], "%d", &c) != 1 || c < 0) {
        fprintf(stderr, "PGM File - second line not cols/rows\n");
        return NULL;
      }
      p = (Pgm *) new_black_pgm_file(r, c);
      state++;
    } else if (state == 2) {
      if (is->NF != 1 || atoi(is->fields[0]) != 255) {
        fprintf(stderr, "PGM File - third line not 255\n");
        return NULL;
      }
      state++;
      r = 0;
      c = 0;
    } else if (state == 3) {
      for (i = 0; i < is->NF; i++) {
        if (sscanf(is->fields[i], "%d", &pixel) != 1 || pixel < 0 || pixel > 255) {
          fprintf(stderr, "Bad pgm file on line %d, row %d, column %d\n", is->line, r, c);
          return NULL;
        }
        p->pixels[r][c] = pixel;
        c++;
        if (c == p->cols) {
          r++;
          c = 0;
        }
        if (r == p->rows) {
          jettison_inputstruct(is);
          return (void *) p;
        }
      }
    }
  }
  fprintf(stderr, "Incomplete PGM file (EOF trying to read row %d column %d)\n", r, c);
  return NULL;
}

int pgm_rows(void *pgm) { return ((Pgm *) pgm)->rows; }
int pgm_cols(void *pgm) { return ((Pgm *) pgm)->cols; }


void jettison_pgm(void *pgm)
{
  Pgm *p;
  int i;

  p = (Pgm *) pgm;
  for (i = 0; i < p->rows; i++) free(p->pixels[i]);
  free(p->pixels);
  free(p);
}
