#include <stdio.h>
#include <stdlib.h>
#include "jpgm.h"


main(int argc, char **argv)
{
  int r, c;
  void *pgm;

  pgm = read_pgm_file(NULL);
  if (pgm == NULL) exit(1);
  write_pgm_file(pgm, NULL);
}
