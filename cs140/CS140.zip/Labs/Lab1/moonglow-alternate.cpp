/**
 * 
 * Lab 1 - moonglow
 * Read a file in Moonglow's format on standard input, and print a very simple output.
 *
 * Moonglow's format: The text file is composed of words. If a word is a number, then
 * that is a student's score on a question, so you add it to the student's exam score.
 * If the word is not a number, but is the word "NAME", then the next word is the
 * student's name (Moonglow only uses first names -- last names are corporate and
 * impersonal). If the word is "AVERAGE", then you start reading numbers until you
 * read a word that is not a number (or is the end of the file). You average all of
 * those numbers and add that to the score. Since Moonglow is a little scatterbrained,
 * sometimes a number does not follow "AVERAGE." In that case, you ignore the "AVERAGE".
 *
 * When you are done reading the file, your program should print the student's name,
 * a space, and the student's score. Just use cout for this -- nothing exciting.
 *
 * Error Checking:
 * The input will specify exactly one student's name.
 * That student's name won't be "AVERAGE" or "NAME." 
 *
 * Author: William McKeehan
 * Date: 01/18/2012
 */
#include <iostream>
#include <string>
#include <sstream>
#include <cstdlib>
using namespace std;

bool isNumber(string input);

int main() {
	string word, name;
	double examScore = 0.0;
	bool avg = false;
	double avgTotal = 0.0;
	int avgCount = 0;

  // read all "words" from standard input
	while(cin >> word) {
		// if if the word is a number, then add to students exam score
		if ( isNumber(word) ) {
			if ( avg ) {
				avgCount++;
				avgTotal += atof(word.c_str());
			} else {
				examScore += atof(word.c_str());
			}
		} else {
			if ( avg ) {
				avg = false;
				if( avgCount > 0 ) examScore += ( avgTotal / avgCount );
				avgTotal = 0;
				avgCount = 0;
			}
			if ( word == "NAME" ) {
				cin >> name;
			}
			if ( word == "AVERAGE" ) {
				avg = true;
			}
		}
	}

	cout << name << " " << examScore << endl;
	exit(0);
}

bool isNumber(string input){
	istringstream inpStream(input);
	double inpValue = 0.0;
	if (inpStream >> inpValue) {
		return true;
	} else {
		return false;
	}	
}
