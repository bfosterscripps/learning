#include <stdio.h>
#include <stdlib.h>
#include "jpgm.h"


main(int argc, char **argv)
{
  int i, j, pix;
  void *pgm;

  pgm = read_pgm_file(NULL);
  for (i = 0; i < pgm_rows(pgm); i++) {
    for (j = 0; j < pgm_cols(pgm); j++) {
      pix = pgm_get_pixel(pgm, i, j);
      pgm_set_pixel(pgm, i, j, 255-pix);
    }
  }
  write_pgm_file(pgm, NULL);
}
