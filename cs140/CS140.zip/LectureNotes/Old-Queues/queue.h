#ifndef _CS140_QUEUE_H
#define _CS140_QUEUE_H
#include "jval.h"

typedef void *Queue;

Queue new_queue();    /* Create an empty queue */

void queue_enqueue(Queue s, Jval jv);  

Jval queue_dequeue(Queue s);  

void free_queue(Queue s); /* This destroys the queue and      
                             frees any memory made by malloc() calls from 
                             within the queue routines.  */

int queue_empty(Queue s); /* This is a boolean function that returns 1 
                            if there are no elements on the queue, 
                            and 0 if there are elements on the queue.  */

int queue_size(Queue s);  /* This returns the number of elements in s. */

#endif
